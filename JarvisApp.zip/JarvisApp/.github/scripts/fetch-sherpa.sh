#!/usr/bin/env bash
# Descarga el motor de voz sherpa-onnx buscando lo que REALMENTE existe en sus releases.
# 1) Si alguna release reciente trae un .aar, se usa.
# 2) Si no, se usa el paquete android (.tar.bz2 con las librerías .so) + el código Kotlin Tts.kt de esa misma versión.
set -uo pipefail
REPO="k2-fsa/sherpa-onnx"
mkdir -p app/libs

tags=$(gh release list --repo "$REPO" --limit 40 --json tagName -q '.[].tagName')
echo "Releases encontradas:"; echo "$tags" | head -20

# --- Opción 1: .aar ---
for tag in $tags; do
  name=$(gh release view "$tag" --repo "$REPO" --json assets -q '.assets[].name' 2>/dev/null | grep -E '\.aar$' | head -1 || true)
  if [ -n "$name" ]; then
    echo "Usando AAR $name de $tag"
    gh release download "$tag" --repo "$REPO" -p "$name" -O app/libs/sherpa-onnx.aar --clobber && exit 0
  fi
done

# --- Opción 2: .so + Tts.kt ---
for tag in $tags; do
  name=$(gh release view "$tag" --repo "$REPO" --json assets -q '.assets[].name' 2>/dev/null | grep -E '^sherpa-onnx-v[0-9.]+-android\.tar\.bz2$' | head -1 || true)
  if [ -n "$name" ]; then
    echo "Usando paquete $name de $tag"
    gh release download "$tag" --repo "$REPO" -p "$name" -O sherpa-android.tar.bz2 --clobber || continue
    mkdir -p sherpa-tmp && tar xjf sherpa-android.tar.bz2 -C sherpa-tmp
    jni=$(find sherpa-tmp -type d -name jniLibs | head -1)
    if [ -z "$jni" ]; then echo "El paquete no trae jniLibs"; continue; fi
    mkdir -p app/src/main/jniLibs && cp -r "$jni"/* app/src/main/jniLibs/
    mkdir -p app/src/main/java/com/k2fsa/sherpa/onnx
    curl -fL -o app/src/main/java/com/k2fsa/sherpa/onnx/Tts.kt \
      "https://raw.githubusercontent.com/$REPO/$tag/sherpa-onnx/kotlin-api/Tts.kt" || { echo "No pude bajar Tts.kt de $tag"; continue; }
    echo "Listo: jniLibs + Tts.kt de $tag"
    exit 0
  fi
done

echo "::error::No pude conseguir sherpa-onnx (ni .aar ni paquete android) en las releases de $REPO"
exit 1
