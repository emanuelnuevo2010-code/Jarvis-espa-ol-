package com.jarvis.assistant

import android.service.notification.NotificationListenerService

/**
 * Servicio vacío: su único trabajo es existir. Cuando el usuario le da el permiso de "Acceso a notificaciones",
 * Android deja que Jarvis hable con los reproductores de música abiertos (sesiones de medios) y les ordene
 * reproducir algo SIN abrir su pantalla, aunque Jarvis esté en segundo plano.
 */
class JarvisNotifListener : NotificationListenerService()
