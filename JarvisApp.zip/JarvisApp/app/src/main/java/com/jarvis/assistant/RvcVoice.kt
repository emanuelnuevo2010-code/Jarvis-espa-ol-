package com.jarvis.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Voces RVC (conversión de voz). RVC no habla por sí solo: Jarvis genera primero su voz normal (la del sistema o
 * una voz importada) y esa voz se "convierte" al timbre del modelo RVC, todo dentro del teléfono con ONNX Runtime.
 *
 * Archivos que necesita (se importan en ajustes, como .zip o .onnx sueltos):
 *   - el modelo RVC exportado a ONNX (los .pth NO corren en el teléfono; se exportan en el RVC WebUI → "Export Onnx")
 *   - un codificador de contenido ONNX (vec-768-layer-12.onnx / hubert / contentvec), uno para todos los modelos
 * No usa el archivo .index (la recuperación por índice no está soportada).
 */
object RvcVoice {
    private val exec = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private val waiters = ConcurrentHashMap<String, (Boolean) -> Unit>()
    @Volatile private var gen = 0
    @Volatile private var track: AudioTrack? = null

    private var env: OrtEnvironment? = null
    private var enc: OrtSession? = null
    private var encKey = ""
    private var syn: OrtSession? = null
    private var synKey = ""

    private fun root(ctx: Context) = File(ctx.filesDir, "rvc").apply { mkdirs() }
    private fun encDir(ctx: Context) = File(root(ctx), "_encoder").apply { mkdirs() }
    private fun isEncoderName(n: String) = n.lowercase().let { it.contains("vec") || it.contains("hubert") || it.contains("encoder") }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", 0)

    /* ---------- estado ---------- */

    private fun synthFile(dir: File): File? =
        dir.walkTopDown().firstOrNull { it.isFile && it.name.endsWith(".onnx") && !isEncoderName(it.name) }

    private fun encoderFile(ctx: Context, dir: File?): File? =
        dir?.walkTopDown()?.firstOrNull { it.isFile && it.name.endsWith(".onnx") && isEncoderName(it.name) }
            ?: encDir(ctx).listFiles()?.firstOrNull { it.name.endsWith(".onnx") }

    fun hasEncoder(ctx: Context) = encoderFile(ctx, null) != null

    fun list(ctx: Context): List<String> =
        root(ctx).listFiles()?.filter { it.isDirectory && it.name != "_encoder" && synthFile(it) != null }?.map { it.name }?.sorted() ?: emptyList()

    /** El modelo RVC elegido, si está completo (modelo + codificador). */
    fun selected(ctx: Context): String? {
        val n = prefs(ctx).getString("rvc_voice", "") ?: ""
        if (n.isBlank()) return null
        val d = File(root(ctx), n)
        return if (d.isDirectory && synthFile(d) != null && encoderFile(ctx, d) != null) n else null
    }

    fun semis(ctx: Context): Float = prefs(ctx).getFloat("rvc_semi", 0f)

    /* ---------- importar / borrar ---------- */

    /** Importa un .zip o un .onnx. Devuelve un mensaje para mostrar al usuario; lanza excepción si no sirve. */
    fun importFile(ctx: Context, uri: Uri): String {
        var display = "rvc"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) display = it.getString(0) ?: display
        }
        val safe = display.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifBlank { "rvc" }
        val input = ctx.contentResolver.openInputStream(uri) ?: error("No pude abrir el archivo.")
        val tmp = File(root(ctx), ".tmp_$safe").apply { deleteRecursively(); mkdirs() }
        try {
            if (display.lowercase().endsWith(".pth")) error(PTH_MSG)
            if (display.lowercase().endsWith(".onnx")) {
                input.use { i -> File(tmp, display.replace(Regex("[^A-Za-z0-9._-]"), "_")).outputStream().use { i.copyTo(it) } }
            } else {
                val tp = tmp.canonicalPath + File.separator
                ZipInputStream(input.buffered()).use { zin ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val out = File(tmp, e.name)
                        if (!out.canonicalPath.startsWith(tp)) continue
                        if (e.isDirectory) { out.mkdirs(); continue }
                        val ok = e.name.lowercase().let { it.endsWith(".onnx") || it.endsWith(".pth") }
                        if (!ok) continue
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                }
            }
            val onnx = tmp.walkTopDown().filter { it.isFile && it.name.endsWith(".onnx") }.toList()
            val hasPth = tmp.walkTopDown().any { it.isFile && it.name.endsWith(".pth") }
            if (onnx.isEmpty()) error(if (hasPth) PTH_MSG else "No encontré ningún archivo .onnx.")
            var msg = ""
            for (f in onnx.filter { isEncoderName(it.name) }) {
                f.copyTo(File(encDir(ctx), f.name), overwrite = true)
                msg = "Codificador “${f.name}” importado."
            }
            val synth = onnx.firstOrNull { !isEncoderName(it.name) }
            if (synth != null) {
                val dest = File(root(ctx), safe)
                dest.deleteRecursively(); dest.mkdirs()
                synth.copyTo(File(dest, synth.name), overwrite = true)
                prefs(ctx).edit().putString("rvc_voice", safe).apply()
                msg = "Modelo “$safe” importado y seleccionado." + if (!hasEncoder(ctx)) " Falta importar el codificador (vec-768-layer-12.onnx)." else ""
            }
            release()
            return msg
        } finally {
            tmp.deleteRecursively()
        }
    }

    private const val PTH_MSG = "Los .pth no corren en el teléfono: hay que exportar el modelo a .onnx (RVC WebUI → pestaña “Export Onnx”) e importar ese .onnx."

    fun delete(ctx: Context, name: String) {
        release()
        File(root(ctx), name).deleteRecursively()
    }

    fun release() {
        gen++; stopTrack()
        exec.execute {
            synchronized(lock) {
                try { enc?.close() } catch (_: Throwable) {}; enc = null; encKey = ""
                try { syn?.close() } catch (_: Throwable) {}; syn = null; synKey = ""
            }
        }
    }

    /* ---------- voz base (la que se convierte) ---------- */

    val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { utteranceId?.let { utt(it, true) } }
        @Suppress("OVERRIDE_DEPRECATION")
        override fun onError(utteranceId: String?) { utteranceId?.let { utt(it, false) } }
        override fun onError(utteranceId: String?, errorCode: Int) { utteranceId?.let { utt(it, false) } }
    }

    /** Para el escuchador del motor de voz: true si el id era de una frase base de RVC. */
    fun utt(id: String, ok: Boolean): Boolean {
        if (!id.startsWith("rvc:")) return false
        waiters[id]?.invoke(ok)
        return true
    }

    /** Voz base: la voz importada (si hay) o la del sistema. Bloquea hasta tener el audio. */
    fun renderBase(ctx: Context, tts: TextToSpeech?, text: String): Pair<FloatArray, Int>? {
        val ext = JarvisVoice.external(ctx)
        if (ext != null) return ExternalVoice.render(ctx, ext, text, JarvisVoice.rate(ctx))
        return renderSystem(tts ?: return null, ctx.cacheDir, text)
    }

    private fun renderSystem(tts: TextToSpeech, cache: File, text: String): Pair<FloatArray, Int>? {
        val id = "rvc:" + System.nanoTime()
        val f = File(cache, "rvc_base.wav")
        val latch = CountDownLatch(1)
        var ok = false
        waiters[id] = { ok = it; latch.countDown() }
        try {
            if (tts.synthesizeToFile(text, Bundle(), f, id) != TextToSpeech.SUCCESS) return null
            if (!latch.await(20, TimeUnit.SECONDS) || !ok) return null
            return readWav(f)
        } finally { waiters.remove(id); f.delete() }
    }

    private fun readWav(f: File): Pair<FloatArray, Int>? {
        val b = f.readBytes()
        if (b.size < 44 || String(b, 0, 4) != "RIFF") return null
        fun le16(o: Int) = (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8)
        fun le32(o: Int) = le16(o) or (le16(o + 2) shl 16)
        var o = 12; var sr = 22050; var ch = 1; var bits = 16
        while (o + 8 <= b.size) {
            val tag = String(b, o, 4); val len = le32(o + 4)
            if (tag == "fmt ") { ch = le16(o + 10); sr = le32(o + 12); bits = le16(o + 22) }
            if (tag == "data") {
                if (bits != 16) return null
                val n = minOf(len, b.size - o - 8) / (2 * ch)
                val out = FloatArray(n)
                for (i in 0 until n) {
                    val p = o + 8 + i * 2 * ch
                    out[i] = ((b[p].toInt() and 0xff) or (b[p + 1].toInt() shl 8)).toShort() / 32768f
                }
                return out to sr
            }
            o += 8 + len + (len and 1)
        }
        return null
    }

    /* ---------- hablar ---------- */

    private fun chunks(text: String): List<String> {
        val parts = text.split(Regex("(?<=[.!?…;:\\n])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>(); var cur = ""
        for (p in parts) { if (cur.isEmpty()) cur = p else if (cur.length < 40) cur += " $p" else { out.add(cur); cur = p } }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    /**
     * Dice el texto con la voz RVC. `render` da el audio de la voz base de cada frase.
     * onDone al terminar; onFail si falla antes de sonar nada (para usar la voz normal).
     */
    fun speak(ctx: Context, name: String, text: String, semis: Float,
              render: (String) -> Pair<FloatArray, Int>?, onDone: () -> Unit, onFail: () -> Unit) {
        val app = ctx.applicationContext
        val my = ++gen
        stopTrack()
        exec.execute {
            if (my != gen) return@execute
            var at: AudioTrack? = null
            var total = 0L
            try {
                ensure(app, name)
                for (ch in chunks(text)) {
                    if (my != gen) return@execute
                    val base = render(ch) ?: error("sin voz base")
                    val out = convert(resample(base.first, base.second, 16000), semis)
                    if (my != gen) return@execute
                    if (at == null) {
                        at = buildTrack(out.second); track = at; at.play()
                    }
                    at.write(out.first, 0, out.first.size, AudioTrack.WRITE_BLOCKING)
                    total += out.first.size
                }
                val a = at
                if (a != null) {
                    var waited = 0
                    while (my == gen && a.playbackHeadPosition < total && waited < 1500) { Thread.sleep(20); waited++ }
                    try { a.stop() } catch (_: Exception) {}
                }
                if (my == gen) onDone()
            } catch (e: Throwable) {
                if (my == gen) { if (total > 0) onDone() else onFail() }
            } finally {
                try { at?.release() } catch (_: Exception) {}
                if (track === at) track = null
            }
        }
    }

    fun stop() { gen++; stopTrack() }

    private fun stopTrack() { val t = track ?: return; try { t.pause(); t.flush() } catch (_: Exception) {} }

    private fun buildTrack(sr: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        return AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, sr * 8))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
    }

    /* ---------- modelos ONNX ---------- */

    private fun ensure(ctx: Context, name: String) {
        synchronized(lock) {
            val e = env ?: OrtEnvironment.getEnvironment().also { env = it }
            val dir = File(root(ctx), name)
            val sf = synthFile(dir) ?: error("Modelo RVC no encontrado")
            val ef = encoderFile(ctx, dir) ?: error("Falta el codificador (vec-768-layer-12.onnx)")
            fun opts() = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            if (encKey != ef.absolutePath || enc == null) {
                try { enc?.close() } catch (_: Throwable) {}
                enc = e.createSession(ef.absolutePath, opts()); encKey = ef.absolutePath
            }
            if (synKey != sf.absolutePath || syn == null) {
                try { syn?.close() } catch (_: Throwable) {}
                syn = e.createSession(sf.absolutePath, opts()); synKey = sf.absolutePath
            }
        }
    }

    private fun resample(x: FloatArray, from: Int, to: Int): FloatArray {
        if (from == to) return x
        val n = (x.size.toLong() * to / from).toInt()
        val out = FloatArray(n)
        val r = from.toDouble() / to
        for (i in 0 until n) {
            val p = i * r; val i0 = p.toInt(); val fr = (p - i0).toFloat()
            val a = x[minOf(i0, x.size - 1)]; val b = x[minOf(i0 + 1, x.size - 1)]
            out[i] = a + (b - a) * fr
        }
        return out
    }

    /** Audio 16 kHz → (audio convertido, frecuencia de muestreo del modelo). */
    private fun convert(wav16: FloatArray, semis: Float): Pair<FloatArray, Int> {
        val e = env!!; val enc = enc!!; val syn = syn!!
        val frames = wav16.size / 160
        if (frames < 4) error("audio muy corto")

        // 1) contenido (50 fps) → 100 fps repitiendo cada cuadro
        val enName = enc.inputNames.first()
        val rank = (enc.inputInfo[enName]!!.info as TensorInfo).shape.size
        val shape = if (rank == 3) longArrayOf(1, 1, wav16.size.toLong()) else longArrayOf(1, wav16.size.toLong())
        var feat = FloatArray(0); var t50 = 0; var dim = 0
        OnnxTensor.createTensor(e, FloatBuffer.wrap(wav16), shape).use { inp ->
            enc.run(mapOf(enName to inp)).use { res ->
                val ot = res[0] as OnnxTensor
                val sh = ot.info.shape
                val fb = ot.floatBuffer; val raw = FloatArray(fb.remaining()); fb.get(raw)
                if (sh.size == 3 && (sh[2] == 768L || sh[2] == 256L)) { t50 = sh[1].toInt(); dim = sh[2].toInt(); feat = raw }
                else { dim = sh[1].toInt(); t50 = sh[2].toInt(); feat = FloatArray(raw.size); for (t in 0 until t50) for (d in 0 until dim) feat[t * dim + d] = raw[d * t50 + t] }
            }
        }
        val phone = FloatArray(frames * dim)
        for (t in 0 until frames) System.arraycopy(feat, minOf(t / 2, t50 - 1) * dim, phone, t * dim, dim)

        // 2) tono (f0) con YIN, transposición y paso a escala "coarse" de RVC
        val f0 = f0Yin(wav16, frames)
        val k = 2.0.pow(semis / 12.0)
        val mMin = 1127.0 * ln(1 + 50.0 / 700); val mMax = 1127.0 * ln(1 + 1100.0 / 700)
        val pitch = LongArray(frames); val pitchf = FloatArray(frames)
        for (t in 0 until frames) {
            val f = (f0[t] * k).toFloat(); pitchf[t] = f
            pitch[t] = if (f <= 0f) 1L else {
                val m = 1127.0 * ln(1 + f / 700.0)
                ((m - mMin) * 254.0 / (mMax - mMin) + 1).coerceIn(1.0, 255.0).roundToInt().toLong()
            }
        }

        // 3) síntesis
        val names = syn.inputNames.toList()
        val rndDim = (syn.inputInfo["rnd"]?.info as? TensorInfo)?.shape?.getOrNull(1)?.takeIf { it > 0 }?.toInt() ?: 192
        val rnd = FloatArray(rndDim * frames); val rg = Random(); for (i in rnd.indices) rnd[i] = rg.nextGaussian().toFloat()
        val toClose = ArrayList<OnnxTensor>()
        try {
            val m = LinkedHashMap<String, OnnxTensor>()
            fun put(n: String, t: OnnxTensor) { if (n in names) { m[n] = t; toClose.add(t) } else t.close() }
            put("phone", OnnxTensor.createTensor(e, FloatBuffer.wrap(phone), longArrayOf(1, frames.toLong(), dim.toLong())))
            put("phone_lengths", OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(frames.toLong())), longArrayOf(1)))
            put("pitch", OnnxTensor.createTensor(e, LongBuffer.wrap(pitch), longArrayOf(1, frames.toLong())))
            put("pitchf", OnnxTensor.createTensor(e, FloatBuffer.wrap(pitchf), longArrayOf(1, frames.toLong())))
            put("ds", OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(0)), longArrayOf(1)))
            put("rnd", OnnxTensor.createTensor(e, FloatBuffer.wrap(rnd), longArrayOf(1, rndDim.toLong(), frames.toLong())))
            if (m.size < 4) error("El modelo RVC no tiene las entradas esperadas (phone, pitch, pitchf, ds, rnd).")
            syn.run(m).use { res ->
                val fb = (res[0] as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining()); fb.get(out)
                val srs = intArrayOf(16000, 22050, 24000, 32000, 40000, 44100, 48000)
                val est = out.size * 100.0 / frames
                val sr = srs.minByOrNull { abs(it - est) } ?: 40000
                var peak = 0f; for (v in out) peak = maxOf(peak, abs(v))
                if (peak > 0.98f) { val g = 0.95f / peak; for (i in out.indices) out[i] *= g }
                return out to sr
            }
        } finally { toClose.forEach { try { it.close() } catch (_: Throwable) {} } }
    }

    /** Tono por YIN: 100 cuadros por segundo a 16 kHz. 0 = sin voz. */
    private fun f0Yin(x: FloatArray, frames: Int): DoubleArray {
        val sr = 16000; val w = 512; val maxTau = sr / 50; val minTau = sr / 1100
        val pad = w + maxTau
        val xp = FloatArray(x.size + 2 * pad); System.arraycopy(x, 0, xp, pad, x.size)
        val d = DoubleArray(maxTau + 2); val cm = DoubleArray(maxTau + 2)
        val raw = DoubleArray(frames)
        for (f in 0 until frames) {
            val st = pad + f * 160 - w / 2
            var en = 0.0; for (j in 0 until w) en += xp[st + j] * xp[st + j]
            if (en < 1e-3 * w) continue
            for (tau in 1..maxTau + 1) {
                var s = 0.0
                for (j in 0 until w) { val df = xp[st + j] - xp[st + j + tau]; s += df * df }
                d[tau] = s
            }
            var run = 0.0
            for (tau in 1..maxTau + 1) { run += d[tau]; cm[tau] = if (run > 0) d[tau] * tau / run else 1.0 }
            var best = -1
            var tau = minTau
            while (tau <= maxTau) {
                if (cm[tau] < 0.15) { while (tau + 1 <= maxTau && cm[tau + 1] < cm[tau]) tau++; best = tau; break }
                tau++
            }
            if (best < 0) continue
            val a = cm[best - 1]; val b = cm[best]; val c = cm[best + 1]
            val den = a - 2 * b + c
            val tf = if (abs(den) > 1e-9) best + 0.5 * (a - c) / den else best.toDouble()
            val hz = sr / tf
            if (hz in 50.0..1100.0) raw[f] = hz
        }
        // mediana de 5 cuadros solo entre los que tienen voz
        val out = DoubleArray(frames)
        for (f in 0 until frames) {
            if (raw[f] <= 0) continue
            val win = ArrayList<Double>()
            for (j in maxOf(0, f - 2)..minOf(frames - 1, f + 2)) if (raw[j] > 0) win.add(raw[j])
            win.sort(); out[f] = win[win.size / 2]
        }
        return out
    }
}
