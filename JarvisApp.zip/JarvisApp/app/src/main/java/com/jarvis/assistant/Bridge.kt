package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import android.speech.tts.TextToSpeech
import org.json.JSONArray
import org.json.JSONObject

/**
 * Punto de encuentro entre el servicio (micrófono + voz) y la página (WebView).
 * Todo ocurre en el hilo principal.
 */
object JarvisHub {
    @Volatile var webView: WebView? = null
    @Volatile var service: JarvisService? = null
    /** true mientras la pantalla de Jarvis está a la vista (entonces la burbuja se esconde). */
    @Volatile var appVisible = false

    private val main = Handler(Looper.getMainLooper())
    private val pending = ArrayList<(JarvisService) -> Unit>()

    /** Ejecuta JavaScript dentro de la página. */
    fun js(code: String) {
        main.post { webView?.evaluateJavascript(code, null) }
    }

    /** Evento de reconocimiento de voz hacia la página (start / result / error / end). */
    fun rec(type: String, payload: JSONObject = JSONObject()) {
        js("window.__rec&&window.__rec(${JSONObject.quote(type)},$payload)")
    }

    /** La voz terminó de hablar la frase con ese id. */
    fun ttsDone(id: String) {
        val n = id.toIntOrNull() ?: return
        js("window.__ttsDone&&window.__ttsDone($n)")
    }

    /** Ejecuta la acción cuando el servicio ya está en primer plano (la deja en espera si aún no). */
    fun withService(action: (JarvisService) -> Unit) {
        main.post {
            val s = service
            if (s != null) action(s) else pending.add(action)
        }
    }

    /** Ejecuta la acción solo si el servicio ya existe. */
    fun ifService(action: (JarvisService) -> Unit) {
        main.post { service?.let(action) }
    }

    fun clearPending() { pending.clear() }

    fun serviceReady(s: JarvisService) {
        service = s
        js("window.__svcReady&&window.__svcReady()")
        val list = ArrayList(pending)
        pending.clear()
        list.forEach { it(s) }
    }

    fun serviceGone() {
        service = null
        pending.clear()
    }

    fun stopService() {
        main.post { service?.shutdown() }
    }
}

/** Funciones que la página puede llamar como `AndroidJarvis.xxx()`. */
class JarvisBridge(private val act: MainActivity) {

    private fun hasMicPerm() = ContextCompat.checkSelfPermission(
        act, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    @JavascriptInterface fun hasMic(): Boolean = hasMicPerm()

    /** true si el servicio de escucha ya está en marcha (la página espera a esto antes de saludar). */
    @JavascriptInterface fun serviceUp(): Boolean = JarvisHub.service != null

    @JavascriptInterface fun askMic() {
        act.runOnUiThread { act.askPermissions() }
    }

    @JavascriptInterface fun service(on: Boolean) {
        if (on) {
            if (!hasMicPerm()) return
            act.runOnUiThread {
                JarvisHub.clearPending()
                try {
                    ContextCompat.startForegroundService(
                        act,
                        Intent(act, JarvisService::class.java).setAction(JarvisService.ACTION_START)
                    )
                } catch (e: Exception) {
                    JarvisHub.js("window.__nativeStopped&&window.__nativeStopped()")
                }
            }
        } else {
            // Con la isla activada, apagar «Activar» no la quita: el servicio se queda y solo deja de escuchar
            val keep = act.getSharedPreferences("jarvis", 0).getBoolean("overlay", true) && Settings.canDrawOverlays(act)
            if (keep && JarvisHub.service != null) JarvisHub.ifService { it.idleKeepIsland() } else JarvisHub.stopService()
        }
    }

    @JavascriptInterface fun recStart(lang: String) {
        if (!hasMicPerm()) {
            JarvisHub.rec("error", JSONObject().put("error", "not-allowed"))
            JarvisHub.rec("end")
            return
        }
        JarvisHub.withService { it.recStart(lang) }
    }

    @JavascriptInterface fun recStop() { JarvisHub.ifService { it.recStop() } }

    @JavascriptInterface fun recAbort() { JarvisHub.ifService { it.recAbort() } }

    @JavascriptInterface fun speak(id: String, text: String) {
        JarvisHub.withService { it.speak(id, text) }
    }

    @JavascriptInterface fun stopSpeak() { JarvisHub.ifService { it.stopSpeak() } }

    /* ---------- burbuja flotante ---------- */

    @JavascriptInterface fun hasOverlay(): Boolean = Settings.canDrawOverlays(act)

    @JavascriptInterface fun askOverlay() {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}"))
                )
            } catch (_: Exception) {}
        }
    }

    /** La página avisa si Jarvis está en reposo (para vigilar la palabra "Jarvis" sin pausar la música). */
    @JavascriptInterface fun wakeIdle(idle: Boolean) { JarvisHub.ifService { it.wakeIdle(idle) } }

    /** Al abrir la app con "Jarvis" activado: cuando el servicio esté en marcha, queda en reposo vigilando la palabra. */
    @JavascriptInterface fun wakeBoot() { JarvisHub.withService { it.wakeIdle(true) } }

    @JavascriptInterface fun wakeWordReady(): Boolean = WakeWord.ready(act)

    /** Estado del detector de «Jarvis», para mostrarlo en Ajustes. */
    @JavascriptInterface fun wakeStatus(): String = JSONObject()
        .put("on", act.getSharedPreferences("jarvis", 0).getBoolean("wake_word", false))
        .put("ready", WakeWord.ready(act)).put("running", WakeWord.running()).put("error", WakeWord.lastError).toString()

    /** Activa o desactiva el despertar con "Jarvis". La primera vez descarga el detector (unos 40 MB). */
    @JavascriptInterface fun setWakeWord(on: Boolean) {
        act.getSharedPreferences("jarvis", 0).edit().putBoolean("wake_word", on).apply()
        if (on && !WakeWord.ready(act)) {
            WakeWord.download(act.applicationContext, onProgress = { p -> JarvisHub.js("window.__wakeProg&&window.__wakeProg($p)") }) { ok ->
                JarvisHub.js("window.__wakeDl&&window.__wakeDl($ok)")
                JarvisHub.ifService { it.wakeRefresh() }
            }
        } else JarvisHub.ifService { it.wakeRefresh() }
    }

    @JavascriptInterface fun setOverlay(on: Boolean) {
        act.getSharedPreferences("jarvis", 0).edit().putBoolean("overlay", on).apply()
        JarvisHub.ifService { it.refreshOverlay() }
    }

    @JavascriptInterface fun overlay(state: String, text: String) {
        JarvisHub.ifService { it.overlaySet(state, text) }
    }

    @JavascriptInterface fun isForeground(): Boolean = JarvisHub.appVisible

    /* ---------- acciones en el teléfono ---------- */

    @JavascriptInterface fun openApp(name: String): String =
        JarvisActions.openApp(act.applicationContext, name)

    @JavascriptInterface fun playSong(query: String, app: String): String =
        JarvisActions.playSong(act.applicationContext, query, app)

    @JavascriptInterface fun media(action: String): String =
        JarvisActions.media(act.applicationContext, action)

    /** Lo que suena ahora: {"ok":true,"title","artist","playing","pos","dur"} (en ms) o {"ok":false} sin acceso a notificaciones. */
    @JavascriptInterface fun nowPlaying(): String {
        val np = JarvisActions.nowPlaying(act.applicationContext) ?: return "{\"ok\":false}"
        return org.json.JSONObject().put("ok", true).put("title", np.title).put("artist", np.artist)
            .put("playing", np.playing).put("pos", np.pos).put("dur", np.dur).toString()
    }

    @JavascriptInterface fun seekFrac(frac: Double): Boolean =
        JarvisActions.seekFrac(act.applicationContext, frac)

    /* ---------- música: app predeterminada, búsqueda, playlists ---------- */

    @JavascriptInterface fun apps(): String = JarvisActions.appsJson(act.applicationContext)

    @JavascriptInterface fun getMusicApp(): String = JarvisActions.getDefaultMusic(act.applicationContext)

    @JavascriptInterface fun setMusicApp(pkg: String) { JarvisActions.setDefaultMusic(act.applicationContext, pkg) }

    @JavascriptInterface fun getMusicApp2(): String = JarvisActions.getBackupMusic(act.applicationContext)

    @JavascriptInterface fun setMusicApp2(pkg: String) { JarvisActions.setBackupMusic(act.applicationContext, pkg) }

    /** kind = "song" o "playlist"; pkg vacío = la app predeterminada. */
    @JavascriptInterface fun playMusic(query: String, kind: String, pkg: String): String =
        JarvisActions.playMusic(act.applicationContext, query, kind, pkg)

    /** «Otra opción»: la misma canción pedida, pero el siguiente resultado de la búsqueda. */
    @JavascriptInterface fun altSong(): String = JarvisActions.playAlternative(act.applicationContext)

    /** ¿Puede Jarvis poner música sin abrir la app (permiso de acceso a notificaciones)? */
    @JavascriptInterface fun bgMusic(): Boolean = JarvisActions.bgEnabled(act.applicationContext)

    @JavascriptInterface fun askBgMusic() {
        act.runOnUiThread {
            try { act.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) {}
        }
    }

    /** ¿Tiene Jarvis el permiso de "Acceso a uso" (para volver a la app en la que estabas)? */
    @JavascriptInterface fun hasUsage(): Boolean = JarvisActions.hasUsage(act.applicationContext)

    @JavascriptInterface fun askUsage() {
        act.runOnUiThread {
            try { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {}
        }
    }

    /* ---------- voz de Jarvis: elegir voz, velocidad y tono ---------- */

    private var listTts: TextToSpeech? = null
    private var listReady = false

    private fun ensureListTts() {
        if (listTts == null) listTts = TextToSpeech(act.applicationContext) {
            listReady = (it == TextToSpeech.SUCCESS)
            if (listReady) listTts?.setOnUtteranceProgressListener(RvcVoice.listener)
        }
    }

    /** Voces instaladas en el teléfono (primero las de español). "[]" si el motor aún está arrancando. */
    @JavascriptInterface fun voices(): String {
        ensureListTts()
        val t = listTts
        if (!listReady || t == null) return "[]"
        val arr = JSONArray()
        try {
            ExternalVoice.list(act.applicationContext).forEach {
                arr.put(JSONObject().put("name", ExternalVoice.PREFIX + it).put("label", "★ $it (archivo importado)"))
            }
        } catch (_: Exception) {}
        try {
            val all = t.voices?.toList() ?: emptyList()
            val es = all.filter { it.locale.language == "es" }
            (if (es.isNotEmpty()) es else all).sortedBy { it.name }.forEach {
                val where = it.locale.displayCountry.ifBlank { it.locale.language }
                arr.put(JSONObject().put("name", it.name).put("label", it.name + " · " + where + (if (it.isNetworkConnectionRequired) " (online)" else "")))
            }
        } catch (_: Exception) {}
        return arr.toString()
    }

    @JavascriptInterface fun getVoiceCfg(): String {
        val p = act.getSharedPreferences("jarvis", 0)
        return JSONObject().put("voice", p.getString("tts_voice", "") ?: "")
            .put("rate", p.getFloat("tts_rate", 1.05f).toDouble()).put("pitch", p.getFloat("tts_pitch", 1.0f).toDouble()).toString()
    }

    @JavascriptInterface fun setVoice(name: String) {
        act.getSharedPreferences("jarvis", 0).edit().putString("tts_voice", name).apply()
        JarvisHub.ifService { it.reloadVoice() }
    }

    @JavascriptInterface fun setVoiceTune(rate: Double, pitch: Double) {
        act.getSharedPreferences("jarvis", 0).edit()
            .putFloat("tts_rate", rate.toFloat().coerceIn(0.5f, 2f)).putFloat("tts_pitch", pitch.toFloat().coerceIn(0.5f, 2f)).apply()
        JarvisHub.ifService { it.reloadVoice() }
    }

    /** Abre el selector de archivos para importar un modelo de voz (.zip). */
    @JavascriptInterface fun importVoice() { act.runOnUiThread { act.pickVoiceFile("tts") } }

    /* ---------- voz RVC (conversión de voz) ---------- */

    @JavascriptInterface fun rvcInfo(): String {
        val ctx = act.applicationContext
        val p = act.getSharedPreferences("jarvis", 0)
        return JSONObject().put("voices", JSONArray(RvcVoice.list(ctx))).put("encoder", RvcVoice.hasEncoder(ctx))
            .put("sel", p.getString("rvc_voice", "") ?: "").put("semi", p.getFloat("rvc_semi", 0f).toDouble()).toString()
    }

    @JavascriptInterface fun setRvc(name: String) {
        act.getSharedPreferences("jarvis", 0).edit().putString("rvc_voice", name).apply()
    }

    @JavascriptInterface fun setRvcSemi(semi: Double) {
        act.getSharedPreferences("jarvis", 0).edit().putFloat("rvc_semi", semi.toFloat().coerceIn(-12f, 12f)).apply()
    }

    @JavascriptInterface fun importRvc() { act.runOnUiThread { act.pickVoiceFile("rvc") } }

    @JavascriptInterface fun deleteRvc(name: String) {
        RvcVoice.delete(act.applicationContext, name)
        val p = act.getSharedPreferences("jarvis", 0)
        if (p.getString("rvc_voice", "") == name) p.edit().putString("rvc_voice", "").apply()
    }

    /** Borra una voz importada (name sin el prefijo "ext:"). */
    @JavascriptInterface fun deleteVoice(name: String) {
        val n = name.removePrefix(ExternalVoice.PREFIX)
        ExternalVoice.delete(act.applicationContext, n)
        val p = act.getSharedPreferences("jarvis", 0)
        if (p.getString("tts_voice", "") == ExternalVoice.PREFIX + n) p.edit().putString("tts_voice", "").apply()
        JarvisHub.ifService { it.reloadVoice() }
    }

    /** Dice una frase con la voz elegida (por el servicio si está activo; si no, con el motor de la lista). */
    @JavascriptInterface fun testVoice(text: String) {
        val s = JarvisHub.service
        if (s != null) { JarvisHub.ifService { it.reloadVoice(); it.speak("test", text) }; return }
        val ctx = act.applicationContext
        val rvc = RvcVoice.selected(ctx)
        if (rvc != null) {
            ensureListTts()
            val t = listTts
            if (listReady && t != null) {
                JarvisVoice.apply(ctx, t)
                RvcVoice.speak(ctx, rvc, text, RvcVoice.semis(ctx), render = { RvcVoice.renderBase(ctx, t, it) }, onDone = {}, onFail = { baseTest(text) })
                return
            }
        }
        baseTest(text)
    }

    private fun baseTest(text: String) {
        val ctx = act.applicationContext
        val ext = JarvisVoice.external(ctx)
        if (ext != null) {
            ExternalVoice.speak(ctx, ext, text, JarvisVoice.rate(ctx), onDone = {}, onFail = { systemTest(text) })
            return
        }
        systemTest(text)
    }

    private fun systemTest(text: String) {
        ensureListTts()
        val t = listTts
        if (listReady && t != null) {
            JarvisVoice.apply(act.applicationContext, t)
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
        }
    }

    /** ¿Está activado el servicio de accesibilidad que toca "play" por ti? */
    @JavascriptInterface fun hasAccess(): Boolean = JarvisAccess.instance != null || try {
        (Settings.Secure.getString(act.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(act.packageName + "/")
    } catch (_: Exception) { false }

    @JavascriptInterface fun askAccess() {
        act.runOnUiThread {
            try { act.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) {}
        }
    }

    @JavascriptInterface fun waPrepare(name: String): String =
        JarvisActions.waPrepare(act.applicationContext, name)

    /** Busca al contacto entre varias formas posibles del nombre (ver JarvisActions.waResolve). */
    @JavascriptInterface fun waResolve(candidates: String): String =
        JarvisActions.waResolve(act.applicationContext, candidates)

    /** Manda el WhatsApp en segundo plano; el resultado vuelve a la página con window.__waDone({ok, opened}). */
    @JavascriptInterface fun waSend(number: String, text: String) {
        val ctx = act.applicationContext
        Thread {
            val r = try { JarvisActions.sendWhatsApp(ctx, number, text) } catch (_: Exception) { JarvisActions.WaResult(false, false) }
            JarvisHub.js("window.__waDone&&window.__waDone(" + JSONObject().put("ok", r.sent).put("opened", r.opened).put("access", JarvisAccess.isOn()) + ")")
        }.start()
    }

    /** Para contactos que solo están en WhatsApp: lo busca dentro de WhatsApp y manda. Resultado igual que waSend. */
    @JavascriptInterface fun waSendByName(name: String, text: String) {
        val ctx = act.applicationContext
        Thread {
            val r = try { JarvisActions.sendWhatsAppByName(ctx, name, text) } catch (_: Exception) { JarvisActions.WaResult(false, false) }
            JarvisHub.js("window.__waDone&&window.__waDone(" + JSONObject().put("ok", r.sent).put("opened", r.opened).put("access", JarvisAccess.isOn()) + ")")
        }.start()
    }

    @JavascriptInterface fun askContacts() {
        act.runOnUiThread { act.askContactsPermission() }
    }

    @JavascriptInterface fun compose(text: String, app: String): String =
        JarvisActions.composeMessage(act.applicationContext, text, app)

    /** Muestra la canción en la isla con botones anterior / pausa / siguiente. */
    @JavascriptInterface fun islandMusic(title: String, app: String) {
        JarvisHub.ifService { it.overlayMusic(title, app) }
    }
}
