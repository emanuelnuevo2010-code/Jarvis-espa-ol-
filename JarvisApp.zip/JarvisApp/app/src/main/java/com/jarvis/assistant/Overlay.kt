package com.jarvis.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Isla flotante de Jarvis (estilo Dynamic Island): una píldora negra arriba y al centro,
 * visible sobre cualquier app. Se expande cuando Jarvis habla y se encoge cuando termina.
 * Al tocarla, abre Jarvis.
 */
class JarvisOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var root: FrameLayout? = null
    private var island: LinearLayout? = null
    private var orb: OrbView? = null
    private var wave: WaveView? = null
    private var label: TextView? = null
    private var controls: LinearLayout? = null
    private var playBtn: IconButton? = null
    private var sub: TextView? = null
    private var musicApp = ""
    private var bar: ProgressLine? = null
    private var barRow: LinearLayout? = null
    private var timeText: TextView? = null
    private var musicAlive = 0L
    private var musicText: String? = null
    private var musicMode = false
    private var resumeMusic = false   // una orden de voz tapó la música: al acabar, la isla vuelve al reproductor
    private var paused = false
    private var state = "idle"
    private var expanded = false
    private var widthAnim: ValueAnimator? = null
    private val collapse = Runnable { collapseNow() }
    private val musicEnd = Runnable { endMusic() }

    /** Cada segundo: lee lo que suena de verdad (título, artista, pausa, progreso) y lo pone en la isla. */
    private val tick = object : Runnable {
        override fun run() {
            if (!musicMode || island == null) return
            val now = SystemClock.uptimeMillis()
            val np = JarvisActions.nowPlaying(ctx)
            if (np != null) {
                musicText = np.title
                label?.text = np.title
                sub?.text = np.artist.ifBlank { musicApp }
                paused = !np.playing
                playBtn?.playing = !paused
                if (np.dur > 0) {
                    barRow?.visibility = View.VISIBLE
                    bar?.frac = (np.pos.toFloat() / np.dur).coerceIn(0f, 1f)
                    timeText?.text = fmt(np.pos) + " / " + fmt(np.dur)
                } else barRow?.visibility = View.GONE
                if (np.playing) musicAlive = now
            }
            // Sin acceso a notificaciones: 30 s como antes. Con él: se queda mientras suene y 45 s en pausa.
            val limit = if (np == null) 30000L else 45000L
            if (now - musicAlive > limit) { endMusic(); return }
            main.postDelayed(this, 1000)
        }
    }

    private fun fmt(ms: Long): String {
        val t = (ms.coerceAtLeast(0) / 1000).toInt()
        return (t / 60).toString() + ":" + (t % 60).toString().padStart(2, '0')
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics
    ).toInt()

    private fun collapsedWidth() = if (state == "idle") dp(86) else dp(128)
    private fun expandedWidth(): Int {
        val screen = ctx.resources.displayMetrics.widthPixels
        return min(dp(320), screen - dp(24))
    }

    fun canShow() = Settings.canDrawOverlays(ctx)
    val isShown get() = root != null
    /** true mientras la isla está en modo música (para que se vea aunque la app esté abierta) */
    val inMusic get() = musicMode
    val attached get() = root?.isAttachedToWindow == true
    var lastError: String? = null

    fun show() {
        if (root != null || !canShow()) return

        val o = OrbView(ctx)
        o.setState(state)
        val w = WaveView(ctx)
        w.setState(state)

        val text = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            alpha = 0f
            setPadding(dp(10), 0, dp(8), 0)
            gravity = Gravity.CENTER_VERTICAL
        }

        val pill = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(38)
            setPadding(dp(8), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.parseColor("#2E4FD1FF"))
            }
            setOnClickListener { openJarvis() }
        }
        fun icon(kind: Int, onTap: (IconButton) -> Unit) = IconButton(ctx, kind).apply {
            setOnClickListener { musicAlive = SystemClock.uptimeMillis(); onTap(this) }
        }
        val prev = icon(IconButton.PREV) { JarvisActions.media(ctx, "prev") }
        val play = icon(IconButton.PLAY) {
            paused = !paused
            JarvisActions.media(ctx, if (paused) "pause" else "play")
            it.playing = !paused
        }
        play.round = true
        play.playing = true
        val next = icon(IconButton.NEXT) { JarvisActions.media(ctx, "next") }
        val volDown = icon(IconButton.VOL_DOWN) { JarvisActions.media(ctx, "vol_down") }
        val volUp = icon(IconButton.VOL_UP) { JarvisActions.media(ctx, "vol_up") }
        val ctl = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            for (v in listOf(volDown, prev, play, next, volUp))
                addView(v, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        pill.addView(o, LinearLayout.LayoutParams(dp(26), dp(26)))
        val subText = TextView(ctx).apply {
            setTextColor(Color.parseColor("#B3FFFFFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(10), 0, dp(8), 0)
            visibility = View.GONE
        }
        val line = ProgressLine(ctx).apply {
            onSeek = { f -> JarvisActions.seekFrac(ctx, f.toDouble()) }
        }
        val time = TextView(ctx).apply {
            setTextColor(Color.parseColor("#99FFFFFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setPadding(dp(6), 0, 0, 0)
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            addView(line, LinearLayout.LayoutParams(0, dp(18), 1f))
            addView(time, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(text, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(subText, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(10); rightMargin = dp(4)
            })
            addView(ctl, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        pill.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        pill.addView(w, LinearLayout.LayoutParams(dp(30), dp(20)))

        val box = FrameLayout(ctx)
        box.addView(
            pill,
            FrameLayout.LayoutParams(collapsedWidth(), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL)
        )

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }

        try {
            wm.addView(box, p)
            root = box; island = pill; orb = o; wave = w; label = text
            controls = ctl; playBtn = play; bar = line; barRow = row; timeText = time; sub = subText
            expanded = false
            if (musicText != null) applyMusic()
        } catch (e: Throwable) {
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
            root = null
        }
    }

    fun hide() {
        main.removeCallbacks(collapse)
        main.removeCallbacks(musicEnd); main.removeCallbacks(tick)
        widthAnim?.cancel(); widthAnim = null
        val r = root ?: return
        orb?.stop(); wave?.stop()
        try { wm.removeView(r) } catch (_: Exception) {}
        root = null; island = null; orb = null; wave = null; label = null
        controls = null; playBtn = null; bar = null; barRow = null; timeText = null; sub = null
        expanded = false
    }

    /** Pone la isla en modo música: título, app y botones. Si la isla aún no se ve, lo aplica al mostrarse. */
    fun showMusic(title: String, app: String) {
        musicText = title.trim(); musicApp = app
        musicMode = true; resumeMusic = false; paused = false; musicAlive = SystemClock.uptimeMillis()
        if (island != null) applyMusic()
    }

    private fun applyMusic() {
        val t = musicText ?: return
        playBtn?.playing = true
        controls?.visibility = View.VISIBLE
        sub?.text = musicApp; sub?.visibility = View.VISIBLE
        label?.setTypeface(null, Typeface.BOLD)
        label?.text = t
        label?.alpha = 1f
        main.removeCallbacks(collapse)
        main.removeCallbacks(musicEnd)
        main.removeCallbacks(tick); main.postDelayed(tick, 800)
        expanded = true
        animateWidth(expandedWidth())
    }

    private fun endMusic() {
        musicMode = false; musicText = null; resumeMusic = false
        main.removeCallbacks(tick)
        JarvisHub.ifService { it.refreshOverlay() }   // si la app está abierta, la isla se esconde al acabar la música
        controls?.visibility = View.GONE; barRow?.visibility = View.GONE; sub?.visibility = View.GONE
        label?.setTypeface(null, Typeface.NORMAL)
        collapseNow()
    }

    /** `text` vacío = solo cambia el estado; con texto = la isla se expande y lo muestra. */
    fun setState(newState: String, text: String?) {
        state = newState
        orb?.setState(newState)
        wave?.setState(newState)
        if (island == null) return
        if (!text.isNullOrBlank()) {
            expand(text.trim())
            return
        }
        if (newState == "speaking") return   // sigue mostrando lo que se está diciendo
        if (musicMode) return                // la canción se queda en la isla
        main.removeCallbacks(collapse)
        main.postDelayed(collapse, 1800)
        if (!expanded) animateWidth(collapsedWidth())
    }

    private fun expand(text: String) {
        val l = label ?: return
        if (musicMode) { controls?.visibility = View.GONE; barRow?.visibility = View.GONE; sub?.visibility = View.GONE; label?.setTypeface(null, Typeface.NORMAL); main.removeCallbacks(tick); musicMode = false; resumeMusic = musicText != null }
        l.text = if (text.length > 120) "…" + text.takeLast(118) else text
        main.removeCallbacks(collapse)
        main.postDelayed(collapse, 12000)
        if (!expanded) {
            expanded = true
            animateWidth(expandedWidth())
            l.animate().alpha(1f).setDuration(220).start()
        }
    }

    private fun collapseNow() {
        if (resumeMusic && musicText != null) {
            resumeMusic = false
            musicMode = true; musicAlive = SystemClock.uptimeMillis()
            if (island != null) applyMusic() else JarvisHub.ifService { it.refreshOverlay() }
            return
        }
        val l = label ?: return
        expanded = false
        l.animate().alpha(0f).setDuration(160).withEndAction { if (!expanded) l.text = "" }.start()
        animateWidth(collapsedWidth())
    }

    private fun animateWidth(target: Int) {
        val pill = island ?: return
        val lp = pill.layoutParams as? FrameLayout.LayoutParams ?: return
        val from = if (lp.width > 0) lp.width else target
        if (from == target) return
        widthAnim?.cancel()
        widthAnim = ValueAnimator.ofInt(from, target).apply {
            duration = 280
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val cur = island?.layoutParams as? FrameLayout.LayoutParams ?: return@addUpdateListener
                cur.width = it.animatedValue as Int
                island?.layoutParams = cur
            }
            start()
        }
    }

    private fun openJarvis() {
        try {
            ctx.startActivity(
                Intent(ctx, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        } catch (_: Exception) {}
    }

    /** Pequeño reactor de arco a la izquierda de la isla. */
    private class OrbView(ctx: Context) : View(ctx) {
        private var state = "idle"
        private var running = true
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val core = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        fun setState(s: String) { state = s }
        fun stop() { running = false }

        override fun onDraw(c: Canvas) {
            val t = System.currentTimeMillis() / 1000f
            val cx = width / 2f; val cy = height / 2f
            val r = min(width, height) / 2f
            val col = colorFor(state)
            val speed = when (state) { "thinking" -> 320f; "speaking" -> 140f; "listening" -> 70f; else -> 24f }
            val pulse = when (state) {
                "speaking" -> 0.5f + 0.5f * sin(t * 9f)
                "listening" -> 0.5f + 0.5f * sin(t * 3.2f)
                "thinking" -> 0.5f + 0.5f * sin(t * 6f)
                else -> 0.35f + 0.15f * sin(t * 1.4f)
            }
            glow.color = col; glow.alpha = (35 + 60 * pulse).toInt()
            c.drawCircle(cx, cy, r * (0.92f + 0.06f * pulse), glow)

            ring.color = col; ring.strokeWidth = r * 0.14f; ring.alpha = 235
            rect.set(cx - r * 0.7f, cy - r * 0.7f, cx + r * 0.7f, cy + r * 0.7f)
            val base = (t * speed) % 360f
            for (i in 0 until 3) c.drawArc(rect, base + i * 120f, 80f, false, ring)

            core.color = col; core.alpha = (170 + 85 * pulse).toInt()
            c.drawCircle(cx, cy, r * (0.22f + 0.07f * pulse), core)

            if (running) postInvalidateOnAnimation()
        }

        override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; postInvalidateOnAnimation() }
        override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
    }

    /** Barritas de sonido a la derecha: se mueven al escuchar y al hablar. */
    private class WaveView(ctx: Context) : View(ctx) {
        private var state = "idle"
        private var running = true
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()

        fun setState(s: String) { state = s }
        fun stop() { running = false }

        override fun onDraw(c: Canvas) {
            val t = System.currentTimeMillis() / 1000f
            val bars = 5
            val gap = width * 0.08f
            val bw = (width - gap * (bars - 1)) / bars
            paint.color = colorFor(state)
            for (i in 0 until bars) {
                val k = when (state) {
                    "speaking" -> 0.35f + 0.65f * abs(sin(t * 8f + i * 1.3f))
                    "listening" -> 0.25f + 0.45f * abs(sin(t * 3f + i * 0.9f))
                    "thinking" -> 0.2f + 0.5f * max(0f, sin(t * 7f - i * 0.9f))
                    else -> 0.15f
                }
                val h = height * k
                val x = i * (bw + gap)
                rect.set(x, (height - h) / 2f, x + bw, (height + h) / 2f)
                paint.alpha = if (state == "idle") 110 else 235
                c.drawRoundRect(rect, bw / 2f, bw / 2f, paint)
            }
            if (running) postInvalidateOnAnimation()
        }

        override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; postInvalidateOnAnimation() }
        override fun onDetachedFromWindow() { running = false; super.onDetachedFromWindow() }
    }
}

/** Barra fina de progreso de la canción. */
private class ProgressLine(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) { field = v; invalidate() }
    var onSeek: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44FFFFFF") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4FD1FF") }
    override fun onDraw(c: Canvas) {
        val th = resources.displayMetrics.density * 4f
        val top = (height - th) / 2f
        val r = th / 2f
        c.drawRoundRect(RectF(0f, top, width.toFloat(), top + th), r, r, track)
        if (frac > 0f) {
            c.drawRoundRect(RectF(0f, top, width * frac, top + th), r, r, fill)
            c.drawCircle(width * frac, height / 2f, th * 1.1f, fill)
        }
    }
    /** Tocar o arrastrar la barra salta a ese punto de la canción. */
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if (width <= 0) return false
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); return true }
            android.view.MotionEvent.ACTION_MOVE -> { frac = (e.x / width).coerceIn(0f, 1f); return true }
            android.view.MotionEvent.ACTION_UP -> {
                frac = (e.x / width).coerceIn(0f, 1f)
                onSeek?.invoke(frac)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Botón con el ícono dibujado a mano (sin emojis): anterior, siguiente, play/pausa y volumen. */
private class IconButton(ctx: Context, val kind: Int) : View(ctx) {
    companion object { const val PREV = 0; const val PLAY = 1; const val NEXT = 2; const val VOL_DOWN = 3; const val VOL_UP = 4 }

    var playing = true
        set(v) { field = v; invalidate() }
    var round = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f
        var fg = Color.WHITE
        if (round) {
            paint.style = Paint.Style.FILL; paint.color = Color.WHITE
            c.drawCircle(cx, cy, 17f * d, paint)
            fg = Color.BLACK
        }
        paint.color = fg; paint.style = Paint.Style.FILL
        val u = 7f * d          // medida base del ícono
        when (kind) {
            PLAY -> if (playing) {
                rect.set(cx - u * 0.75f, cy - u * 0.9f, cx - u * 0.2f, cy + u * 0.9f); c.drawRoundRect(rect, 1.5f * d, 1.5f * d, paint)
                rect.set(cx + u * 0.2f, cy - u * 0.9f, cx + u * 0.75f, cy + u * 0.9f); c.drawRoundRect(rect, 1.5f * d, 1.5f * d, paint)
            } else {
                path.reset(); path.moveTo(cx - u * 0.55f, cy - u); path.lineTo(cx + u * 0.9f, cy); path.lineTo(cx - u * 0.55f, cy + u); path.close()
                c.drawPath(path, paint)
            }
            NEXT, PREV -> {
                val s = if (kind == NEXT) 1f else -1f
                path.reset()
                path.moveTo(cx - s * u * 0.8f, cy - u * 0.8f); path.lineTo(cx + s * u * 0.45f, cy); path.lineTo(cx - s * u * 0.8f, cy + u * 0.8f); path.close()
                c.drawPath(path, paint)
                val x = cx + s * u * 0.8f
                rect.set(x - 1.2f * d, cy - u * 0.8f, x + 1.2f * d, cy + u * 0.8f); c.drawRoundRect(rect, d, d, paint)
            }
            VOL_DOWN, VOL_UP -> {
                val x0 = cx - u * 1.05f
                // altavoz
                path.reset()
                path.moveTo(x0, cy - u * 0.32f); path.lineTo(x0 + u * 0.45f, cy - u * 0.32f); path.lineTo(x0 + u * 1.05f, cy - u * 0.85f)
                path.lineTo(x0 + u * 1.05f, cy + u * 0.85f); path.lineTo(x0 + u * 0.45f, cy + u * 0.32f); path.lineTo(x0, cy + u * 0.32f); path.close()
                c.drawPath(path, paint)
                // ondas: una para bajar, dos para subir
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.6f * d; paint.strokeCap = Paint.Cap.ROUND
                val ax = x0 + u * 1.15f
                rect.set(ax - u * 0.5f, cy - u * 0.5f, ax + u * 0.5f, cy + u * 0.5f); c.drawArc(rect, -50f, 100f, false, paint)
                if (kind == VOL_UP) { rect.set(ax - u * 0.95f, cy - u * 0.95f, ax + u * 0.95f, cy + u * 0.95f); c.drawArc(rect, -50f, 100f, false, paint) }
            }
        }
    }
}

private fun colorFor(state: String): Int = when (state) {
    "thinking" -> Color.parseColor("#FFB347")
    "error" -> Color.parseColor("#FF6B6B")
    else -> Color.parseColor("#4FD1FF")
}
