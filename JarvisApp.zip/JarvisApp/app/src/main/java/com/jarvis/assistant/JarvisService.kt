package com.jarvis.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Locale

/**
 * Servicio en primer plano: mantiene vivo el proceso con el micrófono,
 * escucha con el reconocimiento de voz de Android y habla con el motor de voz del teléfono.
 * La lógica (palabra "Jarvis", IA) sigue en la página.
 */
class JarvisService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.jarvis.assistant.START"
        const val ACTION_STOP = "com.jarvis.assistant.STOP"
        private const val CHANNEL = "jarvis_listen"
        private const val NOTIF_ID = 1
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsFailed = false
    private val pendingSpeak = ArrayList<Pair<String, String>>()
    private var wakeLock: PowerManager.WakeLock? = null
    private var foreground = false
    private val mutedByUs = ArrayList<Int>()
    private var overlay: JarvisOverlay? = null
    private var lastState = "idle"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            JarvisHub.js("window.__nativeStopped&&window.__nativeStopped()")
            shutdown()
            return START_NOT_STICKY
        }
        if (!ensureForeground()) {
            JarvisHub.js("window.__nativeStopped&&window.__nativeStopped()")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun ensureForeground(): Boolean {
        if (foreground) return true
        return try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Jarvis escuchando", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val stop = PendingIntent.getService(
                this, 1,
                Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val nb = NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Jarvis activo")
                .setContentText("Di “Jarvis” y tu pregunta")
                .setOngoing(true)
                .setSilent(true)
                .setContentIntent(open)
                .addAction(0, "Detener", stop)
            val notification = nb.build()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
            foreground = true
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen").apply {
                setReferenceCounted(false)
                acquire(6 * 60 * 60 * 1000L)
            }
            JarvisHub.serviceReady(this)
            refreshOverlay()
            main.removeCallbacks(overlayWatch); main.postDelayed(overlayWatch, 4000)
            true
        } catch (e: Exception) {
            false
        }
    }

    /* ---------- burbuja flotante ---------- */

    /** Muestra la burbuja si está permitida y la app no está a la vista; si no, la esconde. */
    fun refreshOverlay() {
        val o = overlay ?: JarvisOverlay(this).also { overlay = it }
        val wanted = foreground &&
            (!JarvisHub.appVisible || o.inMusic) &&     // con música sonando la isla se ve aunque la app esté abierta
            getSharedPreferences("jarvis", 0).getBoolean("overlay", true)
        if (wanted && o.canShow()) {
            o.show()
            o.setState(lastState, null)
        } else {
            o.hide()
        }
    }

    /** Cada 4 s: si el sistema quitó la isla o no se pudo dibujar, la vuelve a poner. */
    private val overlayWatch = object : Runnable {
        override fun run() {
            if (!foreground) return
            if (!JarvisHub.appVisible || overlay?.inMusic == true) {
                val o = overlay
                if (o == null || !o.isShown || !o.attached) { o?.hide(); refreshOverlay() }
            }
            main.postDelayed(this, 4000)
        }
    }

    fun overlayMusic(title: String, app: String) {
        val o = overlay ?: JarvisOverlay(this).also { overlay = it }
        o.showMusic(title, app)                      // primero el modo música, así refreshOverlay no la esconde
        if (!o.isShown) refreshOverlay()
    }

    fun overlaySet(state: String, text: String) {
        lastState = state
        overlay?.setState(state, text)
    }

    /* ---------- despertar diciendo "Jarvis" (sin pausar la música) ---------- */

    private var wakeIdle = false

    /** La página avisa: true = Jarvis está en reposo (puede vigilar la palabra "Jarvis"); false = está ocupado. */
    fun wakeIdle(idle: Boolean) { wakeIdle = idle; wakeRefresh() }

    fun wakeRefresh() {
        val on = getSharedPreferences("jarvis", 0).getBoolean("wake_word", false)
        if (on && (wakeIdle || JarvisHub.webView == null) && foreground && recognizer == null) {
            if (!WakeWord.ready(this)) { WakeWord.download(this) { ok -> if (ok) main.post { wakeRefresh() } }; return }
            WakeWord.start(this) { main.post { onWakeHit() } }
        } else WakeWord.stop()
    }

    private fun onWakeHit() {
        wakeIdle = false
        // Contesta al instante, desde donde estés (sin esperar a que cargue la pantalla de la app)
        try { speak("wake", listOf("Dígame.", "Aquí estoy.", "A sus órdenes.", "Lo escucho.", "Al habla.").random()) } catch (_: Exception) {}
        if (JarvisHub.webView != null) JarvisHub.js("window.__summon&&window.__summon(true)")
        else try {
            startActivity(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_ASSIST).putExtra("pre", true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (_: Exception) {}
    }

    /* ---------- reconocimiento de voz ---------- */

    fun recStart(lang: String) {
        WakeWord.stop()          // el micrófono es de uno solo: el detector de "Jarvis" lo suelta
        destroyRecognizer()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            JarvisHub.rec("error", JSONObject().put("error", "service-not-allowed"))
            JarvisHub.rec("end")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                if (recognizer === r) JarvisHub.rec("start")
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                if (recognizer !== r) return
                val text = firstText(partialResults)
                if (text.isNotEmpty()) {
                    JarvisHub.rec("result", JSONObject().put("text", text).put("final", false))
                }
            }

            override fun onResults(results: Bundle?) {
                if (recognizer !== r) return
                recognizer = null
                val alts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty()
                val text = alts.firstOrNull().orEmpty()
                if (text.isNotEmpty()) {
                    // Llegan hasta 5 alternativas: la página elige la que mejor encaja (Jarvis, órdenes, contactos)
                    JarvisHub.rec("result", JSONObject().put("text", text).put("final", true).put("alts", org.json.JSONArray(alts)))
                }
                JarvisHub.rec("end")
                main.post { try { r.destroy() } catch (_: Exception) {} }
            }

            override fun onError(error: Int) {
                if (recognizer !== r) return
                recognizer = null
                val code = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                    SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "language-not-supported"
                    else -> "aborted"
                }
                JarvisHub.rec("error", JSONObject().put("error", code))
                JarvisHub.rec("end")
                main.post { try { r.destroy() } catch (_: Exception) {} }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            // Espera un poco más antes de dar por terminada la frase (así no se corta a la mitad)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            // Palabras que el reconocedor debe esperar: "Jarvis", apps y tus contactos (Android 13+)
            if (Build.VERSION.SDK_INT >= 33) {
                try { putStringArrayListExtra(RecognizerIntent.EXTRA_BIASING_STRINGS, biasWords()) } catch (_: Exception) {}
            }
        }
        muteBeep(true)
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            recognizer = null
            JarvisHub.rec("error", JSONObject().put("error", "aborted"))
            JarvisHub.rec("end")
        }
        main.postDelayed({ muteBeep(false) }, 700)
    }

    private var biasCache: ArrayList<String>? = null

    /** "Jarvis", apps de uso común y los nombres de tus contactos (favoritos y más usados primero). */
    private fun biasWords(): ArrayList<String> {
        biasCache?.let { return it }
        val out = arrayListOf("Jarvis", "WhatsApp", "Spotify", "YouTube Music", "YouTube", "Telegram")
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                contentResolver.query(
                    android.provider.ContactsContract.Contacts.CONTENT_URI,
                    arrayOf(android.provider.ContactsContract.Contacts.DISPLAY_NAME), null, null,
                    "starred DESC, times_contacted DESC"
                )?.use { c ->
                    while (c.moveToNext() && out.size < 70) c.getString(0)?.takeIf { it.isNotBlank() }?.let { out.add(it) }
                }
            }
        } catch (_: Exception) {}
        biasCache = out
        return out
    }

    fun recStop() {
        try { recognizer?.stopListening() } catch (_: Exception) {}
    }

    fun recAbort() = destroyRecognizer()

    private fun firstText(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()

    private fun destroyRecognizer() {
        val r = recognizer ?: return
        recognizer = null
        try { r.cancel() } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }

    /** Silencia unos instantes los sonidos del sistema para que no "pite" cada vez que reinicia la escucha. */
    private fun muteBeep(mute: Boolean) {
        try {
            if (mute) {
                for (s in intArrayOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)) {
                    if (!audio.isStreamMute(s)) {
                        audio.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                        mutedByUs.add(s)
                    }
                }
            } else {
                for (s in mutedByUs) audio.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                mutedByUs.clear()
            }
        } catch (_: Exception) {
        }
    }

    /* ---------- voz de salida ---------- */

    override fun onInit(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            ttsFailed = true
            pendingSpeak.forEach { finishSpeak(it.first) }
            pendingSpeak.clear()
            return
        }
        val locale = listOf(
            Locale.forLanguageTag("es-419"),
            Locale.forLanguageTag("es-MX"),
            Locale.forLanguageTag("es-US"),
            Locale.forLanguageTag("es-ES"),
            Locale.forLanguageTag("es")
        ).firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }
        if (locale != null) t.language = locale
        JarvisVoice.apply(this, t)
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                utteranceId?.let { if (!RvcVoice.utt(it, true)) finishSpeak(it) }
            }

            @Suppress("OVERRIDE_DEPRECATION")
            override fun onError(utteranceId: String?) {
                utteranceId?.let { if (!RvcVoice.utt(it, false)) finishSpeak(it) }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                utteranceId?.let { if (!RvcVoice.utt(it, false)) finishSpeak(it) }
            }
        })
        ttsReady = true
        JarvisVoice.external(this)?.let { ExternalVoice.preload(this, it) }
        val list = ArrayList(pendingSpeak)
        pendingSpeak.clear()
        list.forEach { speak(it.first, it.second) }
    }

    /** Aplica de nuevo la voz/velocidad/tono guardados (al cambiarlos en ajustes). */
    fun reloadVoice() {
        tts?.let { if (ttsReady) JarvisVoice.apply(this, it) }
        JarvisVoice.external(this)?.let { ExternalVoice.preload(this, it) }
    }

    /* ---------- bajar la música mientras Jarvis habla ---------- */

    private var focusReq: AudioFocusRequest? = null
    private val abandonRun = Runnable { abandonDuck() }

    /** Pide el foco de audio "con bajada de volumen": la música de otras apps baja mientras Jarvis habla. */
    private fun duck() {
        main.removeCallbacks(abandonRun)
        if (focusReq != null) return
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setWillPauseWhenDucked(false)
                .setOnAudioFocusChangeListener { }
                .build()
            audio.requestAudioFocus(req)
            focusReq = req
        } catch (_: Exception) {}
    }

    /** Devuelve el foco poco después de la última frase (así la música no sube y baja entre frases). */
    private fun unduck() {
        main.removeCallbacks(abandonRun)
        main.postDelayed(abandonRun, 900)
    }

    private fun abandonDuck() {
        val r = focusReq ?: return
        focusReq = null
        try { audio.abandonAudioFocusRequest(r) } catch (_: Exception) {}
    }

    private fun finishSpeak(id: String) {
        JarvisHub.ttsDone(id)
        unduck()
    }

    fun speak(id: String, text: String) {
        duck()
        val rvc = RvcVoice.selected(this)
        if (rvc != null && ttsReady) {
            RvcVoice.speak(this, rvc, text, RvcVoice.semis(this),
                render = { RvcVoice.renderBase(this, tts, it) },
                onDone = { finishSpeak(id) },
                onFail = { main.post { speakBase(id, text) } })
            return
        }
        speakBase(id, text)
    }

    private fun speakBase(id: String, text: String) {
        val ext = JarvisVoice.external(this)
        if (ext != null) {
            ExternalVoice.speak(this, ext, text, JarvisVoice.rate(this),
                onDone = { finishSpeak(id) },
                onFail = { main.post { speakSystem(id, text) } })
            return
        }
        speakSystem(id, text)
    }

    private fun speakSystem(id: String, text: String) {
        if (ttsFailed) { finishSpeak(id); return }
        if (!ttsReady) { pendingSpeak.add(id to text); return }
        val r = try { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) ?: TextToSpeech.ERROR } catch (_: Exception) { TextToSpeech.ERROR }
        if (r == TextToSpeech.SUCCESS) { ttsRestarts = 0; return }
        // El motor de voz del teléfono se cayó (pasa en Xiaomi en segundo plano): se vuelve a crear y se repite la frase
        if (ttsRestarts >= 2) { finishSpeak(id); return }
        ttsRestarts++
        pendingSpeak.add(id to text)
        ttsReady = false; ttsFailed = false
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = TextToSpeech(this, this)
    }
    private var ttsRestarts = 0

    fun stopSpeak() {
        unduck()
        pendingSpeak.clear()
        ExternalVoice.stop()
        RvcVoice.stop()
        try { tts?.stop() } catch (_: Exception) {}
    }

    /* ---------- cierre ---------- */

    /** "Activar" apagado: deja de escuchar y de hablar, pero NO cierra el servicio, así la isla (y la de la música) siguen en pantalla. */
    fun idleKeepIsland() {
        destroyRecognizer()
        stopSpeak()
        muteBeep(false)
        abandonDuck()
        lastState = "idle"
        refreshOverlay()
        wakeRefresh()
    }

    fun shutdown() {
        main.removeCallbacks(overlayWatch)
        WakeWord.stop()
        abandonDuck()
        overlay?.hide(); overlay = null
        destroyRecognizer()
        stopSpeak()
        muteBeep(false)
        releaseWakeLock()
        foreground = false
        JarvisHub.serviceGone()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    override fun onDestroy() {
        main.removeCallbacks(overlayWatch)
        abandonDuck()
        overlay?.hide(); overlay = null
        destroyRecognizer()
        muteBeep(false)
        releaseWakeLock()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        ExternalVoice.release()
        RvcVoice.release()
        JarvisHub.serviceGone()
        super.onDestroy()
    }
}
