package com.jarvis.assistant

import android.app.SearchManager
import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import androidx.core.app.NotificationManagerCompat
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.text.Normalizer

/** Acciones que Jarvis hace en el teléfono: abrir apps, poner canciones, controlar la música. */
object JarvisActions {

    private const val SPOTIFY = "com.spotify.music"
    private const val YT_MUSIC = "com.google.android.apps.youtube.music"
    private const val YOUTUBE = "com.google.android.youtube"

    data class AppInfo(val label: String, val pkg: String)

    internal fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Cómo se dicen en voz alta (o se transcriben) algunas apps → palabras que aparecen en su nombre. */
    private val aliases: Map<String, List<String>> = mapOf(
        "wasap" to listOf("whatsapp"), "guasap" to listOf("whatsapp"), "whats app" to listOf("whatsapp"),
        "wats" to listOf("whatsapp"), "watsap" to listOf("whatsapp"),
        "insta" to listOf("instagram"), "face" to listOf("facebook"), "feis" to listOf("facebook"),
        "tik tok" to listOf("tiktok"), "you tube" to listOf("youtube"), "yutub" to listOf("youtube"),
        "telegram" to listOf("telegram"), "x" to listOf("twitter"), "tuiter" to listOf("twitter"),
        "navegador" to listOf("chrome", "firefox", "browser", "navegador", "internet", "edge"),
        "internet" to listOf("chrome", "firefox", "browser", "internet"),
        "camara" to listOf("camera", "camara"), "ajustes" to listOf("settings", "ajustes", "configuracion"),
        "configuracion" to listOf("settings", "ajustes", "configuracion"),
        "galeria" to listOf("gallery", "galeria", "fotos", "photos"), "fotos" to listOf("photos", "fotos", "gallery", "galeria"),
        "mapas" to listOf("maps", "mapas"), "gmail" to listOf("gmail"), "correo" to listOf("gmail", "mail", "correo", "outlook"),
        "calculadora" to listOf("calculator", "calculadora"), "calendario" to listOf("calendar", "calendario"),
        "reloj" to listOf("clock", "reloj"), "telefono" to listOf("phone", "telefono", "dialer"),
        "llamadas" to listOf("phone", "telefono", "dialer"), "mensajes" to listOf("messages", "mensajes", "sms"),
        "contactos" to listOf("contacts", "contactos"), "musica" to listOf("spotify", "music", "musica"),
        "tienda" to listOf("play store", "tienda"), "play store" to listOf("play store", "tienda"),
        "archivos" to listOf("files", "archivos"), "notas" to listOf("keep", "notes", "notas"),
        "drive" to listOf("drive"), "netflix" to listOf("netflix"), "spotify" to listOf("spotify"),
        "disney" to listOf("disney"), "prime" to listOf("prime video"), "uber" to listOf("uber"),
        "discord" to listOf("discord"), "snapchat" to listOf("snapchat"), "linterna" to listOf("flashlight", "linterna")
    )

    fun launchables(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
    }

    private fun score(app: AppInfo, wanted: String, extra: List<String>): Int {
        val label = norm(app.label)
        val pkg = app.pkg.lowercase()
        var best = 0
        for (w in listOf(wanted) + extra) {
            if (w.isBlank()) continue
            val s = when {
                label == w -> 100
                label.startsWith("$w ") || label.endsWith(" $w") -> 85
                label.contains(w) -> 70
                w.contains(label) && label.length >= 4 -> 60
                pkg.contains(w.replace(" ", "")) -> 50
                else -> {
                    val tokens = w.split(" ").filter { it.length >= 3 }
                    if (tokens.isNotEmpty() && tokens.all { label.contains(it) }) 55 else 0
                }
            }
            if (s > best) best = s
        }
        return best
    }

    fun findApp(ctx: Context, spoken: String): AppInfo? {
        val wanted = norm(spoken)
        if (wanted.isBlank()) return null
        val extra = aliases[wanted] ?: emptyList()
        return launchables(ctx)
            .map { it to score(it, wanted, extra) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
    }

    private fun start(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    /** Abre una app por su nombre hablado. Devuelve JSON: {ok, label} o {ok:false, err}. */
    fun openApp(ctx: Context, spoken: String): String {
        val wanted = norm(spoken)
        val app = findApp(ctx, spoken)
        if (app != null) {
            val launch = ctx.packageManager.getLaunchIntentForPackage(app.pkg)
            if (launch != null && start(ctx, launch)) {
                return JSONObject().put("ok", true).put("label", app.label).toString()
            }
        }
        // Atajos del sistema para lo básico si no hay app con ese nombre
        val system: Intent? = when (wanted) {
            "ajustes", "configuracion", "settings" -> Intent(Settings.ACTION_SETTINGS)
            "camara" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "navegador", "internet" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            else -> null
        }
        if (system != null && start(ctx, system)) {
            return JSONObject().put("ok", true).put("label", spoken).toString()
        }
        return JSONObject().put("ok", false).put("err", if (app == null) "not-found" else "blocked").toString()
    }

    private fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) {
        false
    }

    private val stopWords = setOf("de", "del", "la", "las", "los", "the", "by", "of", "and", "con", "para", "una", "uno")
    private val genericTitle = Regex("^(musica|canciones|cancion|temas|tema|algo|lo mejor|exitos|éxitos|hits)$")

    /** Palabras útiles de lo pedido (para comparar con títulos y artistas). */
    internal fun queryTokens(q: String): List<String> =
        norm(q).split(" ").filter { it.length >= 3 && it !in stopWords }

    /** "Blinding Lights de The Weeknd" → título + artista (se parte por el ÚLTIMO " de " / " by " / " - "). */
    private fun parseQuery(q: String): Pair<String, String?> {
        val m = Regex("^(.+)\\s+(?:de|del|by|of|-)\\s+(.+)$", RegexOption.IGNORE_CASE).find(q.trim())
        return if (m != null) m.groupValues[1].trim() to m.groupValues[2].trim() else q.trim() to null
    }

    /** Extras estándar de "reproducir desde búsqueda" con título y artista, para que la app elija ESA canción. */
    private fun searchExtras(q: String, kind: String): Bundle {
        val b = Bundle()
        b.putString(SearchManager.QUERY, q)
        if (kind == "playlist") {
            b.putString(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Playlists.ENTRY_CONTENT_TYPE)
            b.putString("android.intent.extra.playlist", q)
            return b
        }
        val (title, artist) = parseQuery(q)
        when {
            artist == null && genericTitle.matches(norm(title)) -> b.putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            artist != null && genericTitle.matches(norm(title)) -> {
                b.putString(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)
                b.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist)
            }
            else -> {
                b.putString(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Media.ENTRY_CONTENT_TYPE)
                b.putString(MediaStore.EXTRA_MEDIA_TITLE, title)
                if (artist != null) b.putString(MediaStore.EXTRA_MEDIA_ARTIST, artist)
            }
        }
        return b
    }

    private fun playFromSearch(query: String, pkg: String?, kind: String = "song"): Intent =
        Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtras(searchExtras(query, kind))
            if (pkg != null) setPackage(pkg)
        }

    /** ¿Lo que suena (metadatos de la sesión) coincide con lo pedido? null = no se puede saber. */
    private fun nowMatches(c: MediaController?, q: String): Boolean? {
        val md = c?.metadata ?: return null
        val t = norm((md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + " " + (md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""))
        val tokens = queryTokens(q)
        if (t.isBlank() || tokens.isEmpty()) return null
        return tokens.count { t.contains(it) } >= maxOf(1, (tokens.size + 1) / 2)
    }

    /**
     * Pone una canción. `app` puede ser "spotify", "youtube music", "youtube" o vacío (elige la primera instalada).
     * Devuelve JSON: {ok, app} o {ok:false, err}.
     */
    fun playSong(ctx: Context, query: String, app: String): String {
        val pref = norm(app)
        val order = when {
            pref.contains("spotify") -> listOf(SPOTIFY)
            pref.contains("music") || pref.contains("yt") -> listOf(YT_MUSIC)
            pref.contains("youtube") -> listOf(YOUTUBE)
            else -> listOf(SPOTIFY, YT_MUSIC, YOUTUBE)
        }
        val q = query.trim()
        for (pkg in order.filter { installed(ctx, it) }) {
            val name = when (pkg) { SPOTIFY -> "Spotify"; YT_MUSIC -> "YouTube Music"; else -> "YouTube" }
            if (q.isEmpty()) {
                val launch = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null && start(ctx, launch)) return ok(name)
                continue
            }
            val intent = when (pkg) {
                YOUTUBE -> Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
                ).setPackage(YOUTUBE)
                else -> playFromSearch(q, pkg)
            }
            if (start(ctx, intent)) return ok(name)
            if (pkg == SPOTIFY && start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))))) {
                return ok(name)
            }
        }
        // Cualquier reproductor que sepa buscar y tocar
        if (q.isNotEmpty() && start(ctx, playFromSearch(q, null))) return ok("tu reproductor")
        // Último recurso: YouTube en el navegador
        if (q.isNotEmpty() &&
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        ) return ok("YouTube")
        return JSONObject().put("ok", false).put("err", "no-player").toString()
    }

    private fun ok(app: String) = JSONObject().put("ok", true).put("app", app).toString()

    /* ---------- app de música predeterminada (la que elijas) ---------- */

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", 0)

    fun getDefaultMusic(ctx: Context): String = prefs(ctx).getString("music_pkg", "") ?: ""

    fun setDefaultMusic(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("music_pkg", pkg).apply()
    }

    /** Segunda app de música: se prueba en segundo plano si la principal no logra reproducir. */
    fun getBackupMusic(ctx: Context): String = prefs(ctx).getString("music_pkg2", "") ?: ""

    fun setBackupMusic(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("music_pkg2", pkg).apply()
    }

    /** Todas las apps instaladas (para elegir la de música), las de música conocidas primero. Devuelve JSON array. */
    fun appsJson(ctx: Context): String {
        val known = listOf(SPOTIFY, YT_MUSIC, YOUTUBE, "com.amazon.mp3", "deezer.android.app", "com.apple.android.music",
            "com.soundcloud.android", "com.tidal.android", "com.google.android.music", "com.aspiro.tidal", "org.videolan.vlc")
        val list = launchables(ctx).sortedWith(
            compareBy<AppInfo>({ if (it.pkg in known) 0 else 1 }, { it.label.lowercase() })
        )
        val arr = org.json.JSONArray()
        list.forEach { arr.put(JSONObject().put("label", it.label).put("pkg", it.pkg).put("known", it.pkg in known)) }
        return arr.toString()
    }

    private fun labelOf(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /* ---------- música en segundo plano (sin abrir la pantalla de la app) ---------- */

    /** ¿Tiene Jarvis el permiso de "Acceso a notificaciones"? Con él puede controlar reproductores sin abrirlos. */
    fun bgEnabled(ctx: Context): Boolean = try {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    } catch (e: Exception) { false }

    private fun sessions(ctx: Context): List<MediaController> = try {
        val m = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        m.getActiveSessions(ComponentName(ctx, JarvisNotifListener::class.java))
    } catch (e: Exception) { emptyList() }

    /** Pide a un reproductor (aunque esté cerrado o en pausa) que busque y reproduzca, sin mostrar su pantalla. Solo toca a ESA app. */
    private fun backgroundPlay(ctx: Context, q: String, kind: String, pkg: String): String? {
        if (q.isEmpty() || !bgEnabled(ctx)) return null
        val c = (if (pkg.isNotBlank()) wakeSession(ctx, pkg) else null)
            ?: (if (pkg.isBlank()) sessions(ctx).firstOrNull { it.packageName in listOf(SPOTIFY, YT_MUSIC) } else null)
            ?: return null
        return try {
            val plain = Bundle().apply {
                putString(SearchManager.QUERY, q)
                putString(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            }
            // 1.º con título y artista; 2.º con la búsqueda simple (algunas apps ignoran los datos por separado)
            val tries = if (kind == "playlist") listOf(searchExtras(q, kind)) else listOf(searchExtras(q, kind), plain)
            // Lo que sonaba ANTES de pedir: si ya había una canción en marcha, "está sonando" no basta para dar la pedida por buena
            fun trackOf(mc: MediaController) = mc.metadata?.let {
                (it.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "") + "|" + (it.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "")
            } ?: ""
            val before = trackOf(c)
            val wasPlaying = c.playbackState?.state == PlaybackState.STATE_PLAYING
            for (extras in tries) {
                c.transportControls.playFromSearch(q, extras)
                var loading = false
                for (i in 0 until 8) {                       // hasta ~3 s por intento
                    Thread.sleep(400)
                    val st = c.playbackState?.state
                    val m = if (kind == "playlist") null else nowMatches(c, q)
                    val changed = trackOf(c) != before
                    // Listas: si ya sonaba algo, solo vale cuando cambia la pista; canciones: coincide, o cambió y no se sabe
                    val newOk = if (!wasPlaying) m != false else if (kind == "playlist") changed else (m == true || (m == null && changed))
                    if (st == PlaybackState.STATE_PLAYING && newOk) return bgOk(ctx, c)
                    loading = st == PlaybackState.STATE_BUFFERING || st == PlaybackState.STATE_CONNECTING
                }
                if (loading) return bgOk(ctx, c)             // está cargando (los metadatos aún no cambian)
            }
            null
        } catch (e: Exception) { null }
    }

    private fun bgOk(ctx: Context, c: MediaController): String {
        lastPlayedPkg = c.packageName
        return JSONObject().put("ok", true).put("app", labelOf(ctx, c.packageName)).put("bg", true).toString()
    }

    /** La última app en la que Jarvis puso música: a ella van "pausa", "siguiente", etc. */
    @Volatile private var lastPlayedPkg: String = ""

    /** Botón multimedia dirigido SOLO a esa app (el de AudioManager va a la última que sonó, que puede ser otra). */
    private fun keyTo(ctx: Context, pkg: String, code: Int) {
        for (a in listOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            ctx.sendBroadcast(
                Intent(Intent.ACTION_MEDIA_BUTTON).setPackage(pkg)
                    .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(a, code))
            )
        }
    }

    /**
     * Busca la sesión de medios de esa app. Si no hay (app cerrada o sin reproducir), le manda un "play" de botón
     * multimedia para que arranque su servicio SIN mostrar su pantalla, y espera hasta 2 s a que aparezca la sesión.
     */
    private fun wakeSession(ctx: Context, pkg: String): MediaController? {
        sessions(ctx).firstOrNull { it.packageName == pkg }?.let { return it }
        try {
            for (a in listOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
                ctx.sendBroadcast(
                    Intent(Intent.ACTION_MEDIA_BUTTON).setPackage(pkg)
                        .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(a, KeyEvent.KEYCODE_MEDIA_PLAY))
                )
            }
        } catch (_: Exception) {}
        repeat(10) {
            Thread.sleep(200)
            sessions(ctx).firstOrNull { it.packageName == pkg }?.let { return it }
        }
        return null
    }

    /** Busca en YouTube el primer vídeo (o playlist) que coincide con lo pedido. Devuelve su id o null. Corre fuera del hilo principal. */
    private fun resolveYoutubeId(q: String, kind: String): String? = try {
        val isPl = kind == "playlist"
        val filter = if (isPl) "EgIQAw%3D%3D" else "EgIQAQ%3D%3D"
        val url = java.net.URL("https://www.youtube.com/results?search_query=" + Uri.encode(q) + "&sp=" + filter)
        val c = (url.openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 5000; readTimeout = 6000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            setRequestProperty("Accept-Language", "es,en;q=0.8")
            setRequestProperty("Cookie", "CONSENT=YES+1")
        }
        val html = c.inputStream.bufferedReader().use { it.readText() }
        if (isPl) Regex("\"playlistId\":\"([A-Za-z0-9_-]{10,})\"").find(html)?.groupValues?.get(1)
        else pickBestVideo(html, q)
    } catch (e: Exception) { null }

    /**
     * Entre los primeros resultados elige la primera opción, salvo que hayas dicho el artista ("… de Franz Ferdinand"):
     * entonces gana el resultado de ese canal. Prefiere las versiones oficiales y evita covers, karaokes, remixes, etc.
     */
    private fun pickBestVideo(html: String, q: String): String? {
        val chunks = html.split("\"videoRenderer\":{\"videoId\":\"").drop(1).take(8)
        if (chunks.isEmpty()) return Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)?.groupValues?.get(1)
        val nq = norm(q)
        val qTokens = nq.split(" ").filter { it.length >= 3 }
        val artistTokens = Regex("\\b(?:de|del|by|of)\\s+(.+)$").find(nq)?.groupValues?.get(1)
            ?.split(" ")?.filter { it.length >= 3 } ?: emptyList()
        val bad = Regex("\\b(cover|karaoke|letra|lyrics|lyric|remix|slowed|sped|reverb|8d|nightcore|live|en vivo|instrumental|tutorial|reaccion)\\b")
        var best: String? = null
        var bestScore = Int.MIN_VALUE
        chunks.forEachIndexed { i, c ->
            val id = c.take(11)
            val title = Regex("\"title\":\\{\"runs\":\\[\\{\"text\":\"(.*?)\"").find(c)?.groupValues?.get(1) ?: ""
            val chan = Regex("\"ownerText\":\\{\"runs\":\\[\\{\"text\":\"(.*?)\"").find(c)?.groupValues?.get(1) ?: ""
            val nt = norm(title)
            val nc = norm(chan)
            var sc = 10 - i
            sc += qTokens.count { nt.contains(it) || nc.contains(it) }
            if (artistTokens.isNotEmpty() && artistTokens.all { nc.contains(it) }) sc += 8
            if (nc.endsWith("topic")) sc += 3
            if (nc.contains("vevo")) sc += 2
            if (bad.containsMatchIn(nt) && !bad.containsMatchIn(nq)) sc -= 6
            if (sc > bestScore && Regex("^[A-Za-z0-9_-]{11}$").matches(id)) { bestScore = sc; best = id }
        }
        return best
    }

    /**
     * Después de abrir una canción en la app de música: espera a que suene (hasta 10 s), le da "play" si hace falta
     * (orden a su sesión + toque automático por accesibilidad) y sale de la app: vuelve a Jarvis, a la app anterior o al inicio.
     */
    private fun followUp(ctx: Context, pkg: String, wasVisible: Boolean, prev: String?, q: String) {
        lastPlayedPkg = pkg
        // Espera a que suene la canción PEDIDA (hasta 10 s) y entonces vuelve a donde estabas
        Thread {
            val t0 = android.os.SystemClock.uptimeMillis()
            val canSee = bgEnabled(ctx)
            val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            var lastTry = 0L
            var triedResult = false
            while (android.os.SystemClock.uptimeMillis() - t0 < 10000) {
                try { Thread.sleep(300) } catch (_: Exception) {}
                val el = android.os.SystemClock.uptimeMillis() - t0
                val c = if (canSee) sessions(ctx).firstOrNull { it.packageName == pkg } else null
                val playing = if (canSee) c?.playbackState?.state == PlaybackState.STATE_PLAYING else audio.isMusicActive
                val match = nowMatches(c, q)          // true / false / null (no se sabe)
                if (playing && match != false) { try { Thread.sleep(700) } catch (_: Exception) {}; break }
                if (el < 2500 || el - lastTry < 1200) continue
                lastTry = el
                // Si estamos en la pantalla de resultados (o suena otra cosa), se toca el PRIMER resultado que coincide
                if (JarvisAccess.onResults(pkg, q) || (playing && match == false)) {
                    if (!triedResult) triedResult = JarvisAccess.pressFirstResult(pkg, q)
                    continue
                }
                // Ya estamos en el reproductor: dar play, pero sin "reanudar" una canción vieja que no es la pedida
                if (match != false) {
                    try { if (c != null) c.transportControls.play() else keyTo(ctx, pkg, KeyEvent.KEYCODE_MEDIA_PLAY) } catch (_: Exception) {}
                }
                // La app aún tiene la canción VIEJA: no tocar play (reanudaría esa); esperar a que cargue la pedida
                if (match == false && el < 8000) continue
                if (JarvisAccess.pressPlay(pkg)) { try { Thread.sleep(1200) } catch (_: Exception) {}; if (!canSee) break }
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val back: Intent? = when {
                    wasVisible -> Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                    prev != null -> ctx.packageManager.getLaunchIntentForPackage(prev)
                    else -> null
                }
                if (back == null || !start(ctx, back)) start(ctx, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
            }
        }.start()
    }

    /**
     * Para SimpMusic, YouTube Music y cualquier app que abra enlaces de YouTube Music: busca el id de la canción y abre su enlace directo en esa app, que la reproduce
     * (en vez de dejarte en la pantalla de búsqueda). Después sale de la app solo: vuelve a Jarvis si estaba a la vista, o a la pantalla de inicio.
     */
    private fun playByLink(ctx: Context, q: String, kind: String, pkg: String): String? {
        if (q.isEmpty() || pkg.isBlank() || !installed(ctx, pkg)) return null
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/watch?v=dQw4w9WgXcQ")).setPackage(pkg)
        if (probe.resolveActivity(ctx.packageManager) == null) return null   // esa app no abre enlaces de YouTube Music
        val id = resolveYoutubeId(q, kind) ?: return null
        val link = if (kind == "playlist") "https://music.youtube.com/playlist?list=$id" else "https://music.youtube.com/watch?v=$id"
        val wasVisible = JarvisHub.appVisible
        // La app en la que estabas (hay que leerla ANTES de abrir la de música); necesita "Acceso a uso"
        val prev = if (wasVisible) null else lastForegroundPkg(ctx, setOf(ctx.packageName, pkg))
        if (!start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(link)).setPackage(pkg))) return null
        followUp(ctx, pkg, wasVisible, prev, q)
        return JSONObject().put("ok", true).put("app", labelOf(ctx, pkg)).put("bg", false).toString()
    }

    /**
     * Busca y reproduce una canción o playlist.
     * `kind` = "song" | "playlist". `pkg` vacío = la app predeterminada; si no hay, la primera conocida instalada.
     */
    fun playMusic(ctx: Context, query: String, kind: String, pkg: String): String {
        val q = query.trim()
        val target = pkg.ifBlank { getDefaultMusic(ctx) }
        val wasVisible = JarvisHub.appVisible
        backgroundPlay(ctx, q, kind, target)?.let { return it }
        playByLink(ctx, q, kind, target)?.let { return it }
        if (target.isNotBlank() && installed(ctx, target)) {
            val name = labelOf(ctx, target)
            val prev = if (wasVisible) null else lastForegroundPkg(ctx, setOf(ctx.packageName, target))
            fun done(): String { followUp(ctx, target, wasVisible, prev, q); return ok(name) }
            val launch = ctx.packageManager.getLaunchIntentForPackage(target)
            if (q.isEmpty()) {
                if (launch != null && start(ctx, launch)) return ok(name)
            } else {
                val e = Uri.encode(q)
                // 1) La orden estándar de Android "reproducir desde búsqueda" (con título y artista)
                if (start(ctx, playFromSearch(q, target, kind))) return done()
                // 2) Enlaces de búsqueda propios de cada app (esquema de la app y página web que la app sabe abrir)
                for (u in searchLinks(target, e)) {
                    if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage(target))) return done()
                }
                // 3) Enlaces de búsqueda sin fijar la app: si el esquema es de esa app, Android la elegirá
                for (u in searchLinks(target, e).filter { !it.startsWith("http") }) {
                    if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) return done()
                }
                // 4) Buscador interno de la app (ACTION_SEARCH) y búsqueda web dentro de la app
                if (start(ctx, Intent(Intent.ACTION_SEARCH).setPackage(target).putExtra(SearchManager.QUERY, q))) return done()
                if (start(ctx, Intent(Intent.ACTION_WEB_SEARCH).setPackage(target).putExtra(SearchManager.QUERY, q))) return done()
                // 5) La app no acepta búsquedas desde fuera: se abre ESA app y se copia el nombre para pegarlo
                copyToClipboard(ctx, q)
                if (launch != null && start(ctx, launch)) {
                    return JSONObject().put("ok", true).put("app", name).put("searched", false).toString()
                }
            }
            // Solo si la app elegida no se pudo abrir de ninguna forma, se prueba la segunda opción
            val backup = getBackupMusic(ctx)
            if (backup.isNotBlank() && backup != target && installed(ctx, backup)) {
                backgroundPlay(ctx, q, kind, backup)?.let { return it }
                playByLink(ctx, q, kind, backup)?.let { return it }
            }
            return JSONObject().put("ok", false).put("err", "blocked").put("app", name).toString()
        }
        // Sin app elegida (o ya no está instalada): se busca con la primera que haya
        val fallbackQuery = if (kind == "playlist" && q.isNotEmpty()) "$q playlist" else q
        return playSong(ctx, fallbackQuery, "")
    }

    /** Enlaces de búsqueda conocidos de las apps de música más usadas; para el resto, enlaces genéricos. */
    private fun searchLinks(pkg: String, e: String): List<String> = when (pkg) {
        SPOTIFY -> listOf("spotify:search:$e", "https://open.spotify.com/search/$e")
        YT_MUSIC -> listOf("https://music.youtube.com/search?q=$e")
        YOUTUBE -> listOf("https://www.youtube.com/results?search_query=$e")
        "deezer.android.app" -> listOf("deezer://www.deezer.com/search/$e", "https://www.deezer.com/search/$e")
        "com.amazon.mp3" -> listOf("https://music.amazon.com/search/$e")
        "com.soundcloud.android" -> listOf("soundcloud://search?q=$e", "https://soundcloud.com/search?q=$e")
        "com.aspiro.tidal", "com.tidal.android" -> listOf("tidal://search?q=$e", "https://listen.tidal.com/search?q=$e")
        "com.apple.android.music" -> listOf("https://music.apple.com/search?term=$e")
        "com.audiomack" -> listOf("audiomack://search?q=$e", "https://audiomack.com/search?q=$e")
        "com.napster.service.android", "com.rhapsody.napster" -> listOf("https://play.napster.com/search?query=$e")
        "com.pandora.android" -> listOf("https://www.pandora.com/search/$e")
        "com.anghami" -> listOf("https://play.anghami.com/search/$e")
        "com.clearchannel.iheartradio.controller" -> listOf("https://www.iheart.com/search/?q=$e")
        else -> listOf("https://www.google.com/search?q=$e")
    }

    private fun copyToClipboard(ctx: Context, text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Jarvis", text))
        } catch (_: Exception) {}
    }

    /* ---------- volver a la app anterior (permiso "Acceso a uso") ---------- */

    fun hasUsage(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName) ==
            android.app.AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    /** Última app que estuvo a la vista en el último par de minutos (sin contar las de `exclude`). */
    @Suppress("DEPRECATION")
    private fun lastForegroundPkg(ctx: Context, exclude: Set<String>): String? {
        if (!hasUsage(ctx)) return null
        return try {
            val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 120000, now)
            val e = android.app.usage.UsageEvents.Event()
            var last: String? = null
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == android.app.usage.UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName !in exclude) last = e.packageName
            }
            last
        } catch (e: Exception) { null }
    }

    /* ---------- lo que suena ahora (para la isla) ---------- */

    data class NowPlaying(val title: String, val artist: String, val playing: Boolean, val pos: Long, val dur: Long)

    /** Título, artista, estado y posición de lo que suena. Necesita el acceso a notificaciones; si no, devuelve null. */
    fun nowPlaying(ctx: Context): NowPlaying? {
        if (!bgEnabled(ctx)) return null
        val list = sessions(ctx)
        val pref = getDefaultMusic(ctx)
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull { it.packageName == pref } ?: list.firstOrNull() ?: return null
        val m = c.metadata
        val st = c.playbackState
        val title = m?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: return null
        val artist = m.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val playing = st?.state == PlaybackState.STATE_PLAYING || st?.state == PlaybackState.STATE_BUFFERING
        var pos = st?.position ?: 0L
        if (st != null && st.state == PlaybackState.STATE_PLAYING && st.position >= 0) {
            pos += ((android.os.SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        return NowPlaying(title, artist, playing, pos, m.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION))
    }

    /** Salta a un punto de la canción que suena (frac 0..1). Necesita el acceso a notificaciones. */
    fun seekFrac(ctx: Context, frac: Double): Boolean {
        if (!bgEnabled(ctx)) return false
        val list = sessions(ctx)
        val pref = getDefaultMusic(ctx)
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull { it.packageName == pref } ?: list.firstOrNull() ?: return false
        val dur = c.metadata?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (dur <= 0) return false
        return try { c.transportControls.seekTo((dur * frac.coerceIn(0.0, 1.0)).toLong()); true } catch (_: Exception) { false }
    }

    /* ---------- mandar un WhatsApp a un contacto, sin tocar nada ---------- */

    private fun loadPeople(ctx: Context): LinkedHashMap<String, Pair<String, MutableList<Pair<String, Int>>>> {
        // nombre normalizado -> (nombre tal cual, [(número, tipo)])
        val people = LinkedHashMap<String, Pair<String, MutableList<Pair<String, Int>>>>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val num = c.getString(1) ?: continue
                    people.getOrPut(norm(name)) { name to mutableListOf() }.second.add(num to c.getInt(2))
                }
            }
        } catch (_: Exception) {}
        // Contactos que WhatsApp sincroniza por su cuenta (aunque no tengan teléfono en la agenda): su número viene en "número@s.whatsapp.net"
        try {
            ctx.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1),
                ContactsContract.Data.MIMETYPE + "=?", arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile"), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val digits = (c.getString(1) ?: "").substringBefore("@").filter { it.isDigit() }
                    if (digits.length < 7) continue
                    people.getOrPut(norm(name)) { name to mutableListOf() }.second.add(digits to WA_NUMBER)
                }
            }
        } catch (_: Exception) {}
        return people
    }

    private const val WA_NUMBER = 99

    /** Número del contacto en formato internacional, solo dígitos (prefiere el móvil). */
    private fun bestNumber(ctx: Context, nums: List<Pair<String, Int>>): String {
        nums.firstOrNull { it.second == WA_NUMBER }?.let { return it.first }   // el de WhatsApp ya viene completo, con código de país
        val raw = (nums.firstOrNull { it.second == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE } ?: nums.first()).first
        val iso = try {
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            (tm.networkCountryIso.ifBlank { tm.simCountryIso }.ifBlank { java.util.Locale.getDefault().country }).uppercase()
        } catch (_: Exception) { java.util.Locale.getDefault().country }
        val e164 = try { android.telephony.PhoneNumberUtils.formatNumberToE164(raw, iso) } catch (_: Exception) { null }
        return (e164 ?: raw).filter { it.isDigit() }
    }

    /** Cómo suena una palabra en español (v=b, h muda, ll=y, c/k/q, z=s, g/j…): "Yei", "Jey" y "Llei" se parecen. */
    private fun phon(w: String): String {
        var t = norm(w).replace(" ", "")
        t = t.replace("ch", "1").replace("ph", "f").replace("qu", "k").replace("ll", "i")
            .replace("gue", "2e").replace("gui", "2i")
            .replace(Regex("g(?=[ei])"), "x").replace("j", "x")
            .replace(Regex("c(?=[ei])"), "s").replace("c", "k")
            .replace("v", "b").replace("z", "s").replace("w", "u").replace("y", "i").replace("h", "").replace("2", "g")
        return t.replace(Regex("(.)\\1+"), "$1")
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1); cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = cur
        }
        return prev[b.length]
    }

    /** level 0: palabra igual / comienzo de palabra · 1: suena igual · 2: se parece (1–2 letras de diferencia). */
    private fun wordMatches(t: String, w: String, level: Int): Boolean = when (level) {
        0 -> w == t || (t.length >= 4 && w.startsWith(t))
        1 -> { val pt = phon(t); val pw = phon(w); pt.isNotEmpty() && (pw == pt || (pt.length >= 3 && pw.startsWith(pt))) }
        else -> { val pt = phon(t); val pw = phon(w); pt.length >= 4 && pw.length >= 3 && lev(pt, pw) <= (if (pt.length >= 7) 2 else 1) }
    }

    /** Contactos cuyo nombre trae todas esas palabras (con el nivel de parecido indicado). */
    private fun findPeople(
        people: Map<String, Pair<String, MutableList<Pair<String, Int>>>>, query: String, level: Int = 0
    ): Pair<List<String>, Pair<String, MutableList<Pair<String, Int>>>?> {
        val tokens = norm(query).replace(Regex("^(mi|mis|el|la|a)\\s+"), "").split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) return emptyList<String>() to null
        if (level == 2 && tokens.size > 2) return emptyList<String>() to null
        val joined = phon(tokens.joinToString(""))
        val matches = people.filter { (k, _) ->
            val words = k.split(" ")
            tokens.all { t -> words.any { w -> wordMatches(t, w, level) } } ||
                // "Jose Luis" dicho como "joseluis" (o al revés)
                (level >= 1 && tokens.size >= 2 && phon(k).let { it == joined || it.startsWith(joined) })
        }
        if (matches.isEmpty()) return emptyList<String>() to null
        val chosen = matches[tokens.joinToString(" ")]
            ?: matches.entries.firstOrNull { phon(it.key) == joined }?.value
            ?: if (matches.size == 1) matches.values.first() else null
        return matches.values.map { it.first } to chosen
    }

    private fun noContactsPermission(ctx: Context) =
        ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED

    /** Busca al contacto por nombre. status: ok (name, number) | ambiguous (names) | none | nopermission. */
    fun waPrepare(ctx: Context, query: String): String =
        waResolve(ctx, org.json.JSONArray().put(JSONObject().put("k", 0).put("q", query)).toString())

    /**
     * Recibe las posibles formas del nombre, de la más larga a la más corta: [{k: nº de palabras, q: "juan perez"}, …].
     * Sirve para separar "mándale a Juan llego tarde" en contacto («Juan») y mensaje («llego tarde») sin necesitar un "que".
     * status: ok (name, number, k) | ambiguous (names, k) | none | nopermission.
     */
    fun waResolve(ctx: Context, candidatesJson: String): String {
        if (noContactsPermission(ctx)) return JSONObject().put("status", "nopermission").toString()
        val people = loadPeople(ctx)
        if (people.isEmpty()) return JSONObject().put("status", "empty").toString()
        val arr = try { org.json.JSONArray(candidatesJson) } catch (_: Exception) { return JSONObject().put("status", "none").toString() }
        // Primero el nombre tal cual, luego "suena igual" y por último "se parece": así "Yei" encuentra a "Jey", "Ale" a "Alé", etc.
        for (level in 0..2) for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val k = o.optInt("k"); val (names, chosen) = findPeople(people, o.optString("q"), level)
            if (names.isEmpty()) continue
            if (chosen == null) {
                val list = org.json.JSONArray(); names.take(4).forEach { list.put(it) }
                return JSONObject().put("status", "ambiguous").put("names", list).put("k", k).toString()
            }
            return JSONObject().put("status", "ok").put("name", chosen.first).put("number", bestNumber(ctx, chosen.second)).put("k", k).toString()
        }
        return JSONObject().put("status", "none").toString()
    }

    data class WaResult(val opened: Boolean, val sent: Boolean)

    /** Abre el chat con ese número con el texto ya escrito y, si la accesibilidad está activa, toca "enviar". Bloquea hasta ~12 s: llamar desde un hilo. */
    fun sendWhatsApp(ctx: Context, number: String, text: String): WaResult {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) } ?: return WaResult(false, false)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + number + "?text=" + Uri.encode(text)))
            .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!start(ctx, i)) return WaResult(false, false)
        if (!JarvisAccess.isOn()) return WaResult(true, false)
        val end = android.os.SystemClock.uptimeMillis() + 12000
        while (android.os.SystemClock.uptimeMillis() < end) {
            try { Thread.sleep(500) } catch (_: InterruptedException) {}
            if (JarvisAccess.pressSend(pkg, text)) { try { Thread.sleep(700) } catch (_: InterruptedException) {}; return WaResult(true, true) }
        }
        return WaResult(true, false)
    }

    /**
     * Último recurso, para contactos que solo existen dentro de WhatsApp: abre "compartir" con el texto, busca el nombre
     * en la lista de WhatsApp con la accesibilidad y manda. Si hay dudas (varios parecidos, no aparece) NO manda. Bloquea hasta ~25 s.
     */
    fun sendWhatsAppByName(ctx: Context, name: String, text: String): WaResult {
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { installed(ctx, it) } ?: return WaResult(false, false)
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!start(ctx, i)) return WaResult(false, false)
        if (!JarvisAccess.isOn()) return WaResult(true, false)
        return WaResult(true, JarvisAccess.shareToContact(pkg, name, text))
    }

    /** Abre un chat de WhatsApp (o la app de mensajes) con el texto ya escrito; tú solo das a enviar. */
    fun composeMessage(ctx: Context, text: String, app: String): String {
        val pref = norm(app)
        val pkg = when {
            pref.contains("telegram") -> "org.telegram.messenger"
            pref.contains("messenger") -> "com.facebook.orca"
            pref.contains("mensaje") || pref.contains("sms") -> ""
            else -> "com.whatsapp"
        }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        if (pkg.isNotEmpty() && installed(ctx, pkg)) {
            if (start(ctx, Intent(send).setPackage(pkg))) return ok(labelOf(ctx, pkg))
        }
        if (pkg.isEmpty()) {
            if (start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", text))) return ok("Mensajes")
        }
        val chooser = Intent.createChooser(send, "Enviar con…")
        return if (start(ctx, chooser)) ok("selector") else JSONObject().put("ok", false).toString()
    }

    /** Controla lo que esté sonando: play, pause, toggle, next, prev, vol_up, vol_down. */
    fun media(ctx: Context, action: String): String {
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY; "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE; "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> -1
        }
        if (code != -1) {
            // Si hay varias apps de música, la orden va a la de Jarvis (la elegida), no a la última que sonó
            val want = lastPlayedPkg.ifBlank { getDefaultMusic(ctx) }
            val c = if (want.isNotBlank() && bgEnabled(ctx)) sessions(ctx).firstOrNull { it.packageName == want } else null
            if (c != null) {
                try {
                    val t = c.transportControls
                    when (action) {
                        "play" -> t.play(); "pause" -> t.pause(); "next" -> t.skipToNext(); "prev" -> t.skipToPrevious()
                        else -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                    }
                    return JSONObject().put("ok", true).toString()
                } catch (_: Exception) {}
            }
        }
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun key(code: Int) {
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
        return try {
            when (action) {
                "play" -> key(KeyEvent.KEYCODE_MEDIA_PLAY)
                "pause" -> key(KeyEvent.KEYCODE_MEDIA_PAUSE)
                "toggle" -> key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                "next" -> key(KeyEvent.KEYCODE_MEDIA_NEXT)
                "prev" -> key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "vol_up" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "vol_down" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                else -> return JSONObject().put("ok", false).toString()
            }
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).toString()
        }
    }
}
