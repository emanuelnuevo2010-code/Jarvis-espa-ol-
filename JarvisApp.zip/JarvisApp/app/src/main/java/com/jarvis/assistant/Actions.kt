package com.jarvis.assistant

import android.app.SearchManager
import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import androidx.core.app.NotificationManagerCompat
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONObject
import java.text.Normalizer

/** Acciones que Jarvis hace en el teléfono: abrir apps, poner canciones, controlar la música. */
object JarvisActions {

    private const val SPOTIFY = "com.spotify.music"
    private const val YT_MUSIC = "com.google.android.apps.youtube.music"
    private const val YOUTUBE = "com.google.android.youtube"

    data class AppInfo(val label: String, val pkg: String)

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Cómo se dicen en voz alta (o se transcriben) algunas apps → palabras que aparecen en su nombre. */
    private val aliases: Map<String, List<String>> = mapOf(
        "wasap" to listOf("whatsapp"), "guasap" to listOf("whatsapp"), "whats app" to listOf("whatsapp"),
        "wats" to listOf("whatsapp"), "watsap" to listOf("whatsapp"),
        "insta" to listOf("instagram"), "face" to listOf("facebook"), "feis" to listOf("facebook"),
        "tik tok" to listOf("tiktok"), "you tube" to listOf("youtube"), "yutub" to listOf("youtube"),
        "telegram" to listOf("telegram"), "x" to listOf("twitter"), "tuiter" to listOf("twitter"),
        "navegador" to listOf("chrome", "firefox", "browser", "navegador", "internet", "edge"),
        "internet" to listOf("chrome", "firefox", "browser", "internet"),
        "camara" to listOf("camera", "camara"), "ajustes" to listOf("settings", "ajustes", "configuracion"),
        "configuracion" to listOf("settings", "ajustes", "configuracion"),
        "galeria" to listOf("gallery", "galeria", "fotos", "photos"), "fotos" to listOf("photos", "fotos", "gallery", "galeria"),
        "mapas" to listOf("maps", "mapas"), "gmail" to listOf("gmail"), "correo" to listOf("gmail", "mail", "correo", "outlook"),
        "calculadora" to listOf("calculator", "calculadora"), "calendario" to listOf("calendar", "calendario"),
        "reloj" to listOf("clock", "reloj"), "telefono" to listOf("phone", "telefono", "dialer"),
        "llamadas" to listOf("phone", "telefono", "dialer"), "mensajes" to listOf("messages", "mensajes", "sms"),
        "contactos" to listOf("contacts", "contactos"), "musica" to listOf("spotify", "music", "musica"),
        "tienda" to listOf("play store", "tienda"), "play store" to listOf("play store", "tienda"),
        "archivos" to listOf("files", "archivos"), "notas" to listOf("keep", "notes", "notas"),
        "drive" to listOf("drive"), "netflix" to listOf("netflix"), "spotify" to listOf("spotify"),
        "disney" to listOf("disney"), "prime" to listOf("prime video"), "uber" to listOf("uber"),
        "discord" to listOf("discord"), "snapchat" to listOf("snapchat"), "linterna" to listOf("flashlight", "linterna")
    )

    fun launchables(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
    }

    private fun score(app: AppInfo, wanted: String, extra: List<String>): Int {
        val label = norm(app.label)
        val pkg = app.pkg.lowercase()
        var best = 0
        for (w in listOf(wanted) + extra) {
            if (w.isBlank()) continue
            val s = when {
                label == w -> 100
                label.startsWith("$w ") || label.endsWith(" $w") -> 85
                label.contains(w) -> 70
                w.contains(label) && label.length >= 4 -> 60
                pkg.contains(w.replace(" ", "")) -> 50
                else -> {
                    val tokens = w.split(" ").filter { it.length >= 3 }
                    if (tokens.isNotEmpty() && tokens.all { label.contains(it) }) 55 else 0
                }
            }
            if (s > best) best = s
        }
        return best
    }

    fun findApp(ctx: Context, spoken: String): AppInfo? {
        val wanted = norm(spoken)
        if (wanted.isBlank()) return null
        val extra = aliases[wanted] ?: emptyList()
        return launchables(ctx)
            .map { it to score(it, wanted, extra) }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }
            ?.first
    }

    private fun start(ctx: Context, intent: Intent): Boolean = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    /** Abre una app por su nombre hablado. Devuelve JSON: {ok, label} o {ok:false, err}. */
    fun openApp(ctx: Context, spoken: String): String {
        val wanted = norm(spoken)
        val app = findApp(ctx, spoken)
        if (app != null) {
            val launch = ctx.packageManager.getLaunchIntentForPackage(app.pkg)
            if (launch != null && start(ctx, launch)) {
                return JSONObject().put("ok", true).put("label", app.label).toString()
            }
        }
        // Atajos del sistema para lo básico si no hay app con ese nombre
        val system: Intent? = when (wanted) {
            "ajustes", "configuracion", "settings" -> Intent(Settings.ACTION_SETTINGS)
            "camara" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "navegador", "internet" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            else -> null
        }
        if (system != null && start(ctx, system)) {
            return JSONObject().put("ok", true).put("label", spoken).toString()
        }
        return JSONObject().put("ok", false).put("err", if (app == null) "not-found" else "blocked").toString()
    }

    private fun installed(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: Exception) {
        false
    }

    private fun playFromSearch(query: String, pkg: String?): Intent =
        Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, query)
            if (pkg != null) setPackage(pkg)
        }

    /**
     * Pone una canción. `app` puede ser "spotify", "youtube music", "youtube" o vacío (elige la primera instalada).
     * Devuelve JSON: {ok, app} o {ok:false, err}.
     */
    fun playSong(ctx: Context, query: String, app: String): String {
        val pref = norm(app)
        val order = when {
            pref.contains("spotify") -> listOf(SPOTIFY)
            pref.contains("music") || pref.contains("yt") -> listOf(YT_MUSIC)
            pref.contains("youtube") -> listOf(YOUTUBE)
            else -> listOf(SPOTIFY, YT_MUSIC, YOUTUBE)
        }
        val q = query.trim()
        for (pkg in order.filter { installed(ctx, it) }) {
            val name = when (pkg) { SPOTIFY -> "Spotify"; YT_MUSIC -> "YouTube Music"; else -> "YouTube" }
            if (q.isEmpty()) {
                val launch = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null && start(ctx, launch)) return ok(name)
                continue
            }
            val intent = when (pkg) {
                YOUTUBE -> Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
                ).setPackage(YOUTUBE)
                else -> playFromSearch(q, pkg)
            }
            if (start(ctx, intent)) return ok(name)
            if (pkg == SPOTIFY && start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q))))) {
                return ok(name)
            }
        }
        // Cualquier reproductor que sepa buscar y tocar
        if (q.isNotEmpty() && start(ctx, playFromSearch(q, null))) return ok("tu reproductor")
        // Último recurso: YouTube en el navegador
        if (q.isNotEmpty() &&
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
        ) return ok("YouTube")
        return JSONObject().put("ok", false).put("err", "no-player").toString()
    }

    private fun ok(app: String) = JSONObject().put("ok", true).put("app", app).toString()

    /* ---------- app de música predeterminada (la que elijas) ---------- */

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", 0)

    fun getDefaultMusic(ctx: Context): String = prefs(ctx).getString("music_pkg", "") ?: ""

    fun setDefaultMusic(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("music_pkg", pkg).apply()
    }

    /** Segunda app de música: se prueba en segundo plano si la principal no logra reproducir. */
    fun getBackupMusic(ctx: Context): String = prefs(ctx).getString("music_pkg2", "") ?: ""

    fun setBackupMusic(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("music_pkg2", pkg).apply()
    }

    /** Todas las apps instaladas (para elegir la de música), las de música conocidas primero. Devuelve JSON array. */
    fun appsJson(ctx: Context): String {
        val known = listOf(SPOTIFY, YT_MUSIC, YOUTUBE, "com.amazon.mp3", "deezer.android.app", "com.apple.android.music",
            "com.soundcloud.android", "com.tidal.android", "com.google.android.music", "com.aspiro.tidal", "org.videolan.vlc")
        val list = launchables(ctx).sortedWith(
            compareBy<AppInfo>({ if (it.pkg in known) 0 else 1 }, { it.label.lowercase() })
        )
        val arr = org.json.JSONArray()
        list.forEach { arr.put(JSONObject().put("label", it.label).put("pkg", it.pkg).put("known", it.pkg in known)) }
        return arr.toString()
    }

    private fun labelOf(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    /* ---------- música en segundo plano (sin abrir la pantalla de la app) ---------- */

    /** ¿Tiene Jarvis el permiso de "Acceso a notificaciones"? Con él puede controlar reproductores sin abrirlos. */
    fun bgEnabled(ctx: Context): Boolean = try {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    } catch (e: Exception) { false }

    private fun sessions(ctx: Context): List<MediaController> = try {
        val m = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        m.getActiveSessions(ComponentName(ctx, JarvisNotifListener::class.java))
    } catch (e: Exception) { emptyList() }

    /** Pide a un reproductor que ya está abierto (aunque en pausa) que busque y reproduzca, sin mostrar su pantalla. */
    private fun backgroundPlay(ctx: Context, q: String, kind: String, pkg: String): String? {
        if (q.isEmpty() || !bgEnabled(ctx)) return null
        val c = (if (pkg.isNotBlank()) wakeSession(ctx, pkg) else null)
            ?: (if (pkg.isBlank()) sessions(ctx).firstOrNull { it.packageName in listOf(SPOTIFY, YT_MUSIC) } else null)
            ?: return null
        return try {
            val extras = Bundle().apply {
                putString(MediaStore.EXTRA_MEDIA_FOCUS,
                    if (kind == "playlist") "vnd.android.cursor.item/playlist" else "vnd.android.cursor.item/*")
            }
            c.transportControls.playFromSearch(q, extras)
            // Comprobamos que de verdad suena; si la app ignora la orden, devolvemos null y se usa el método de antes
            Thread.sleep(1500)
            val st = c.playbackState?.state
            if (st != PlaybackState.STATE_PLAYING && st != PlaybackState.STATE_BUFFERING) return null
            JSONObject().put("ok", true).put("app", labelOf(ctx, c.packageName)).put("bg", true).toString()
        } catch (e: Exception) { null }
    }

    /**
     * Busca la sesión de medios de esa app. Si no hay (app cerrada o sin reproducir), le manda un "play" de botón
     * multimedia para que arranque su servicio SIN mostrar su pantalla, y espera hasta 2 s a que aparezca la sesión.
     */
    private fun wakeSession(ctx: Context, pkg: String): MediaController? {
        sessions(ctx).firstOrNull { it.packageName == pkg }?.let { return it }
        try {
            for (a in listOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
                ctx.sendBroadcast(
                    Intent(Intent.ACTION_MEDIA_BUTTON).setPackage(pkg)
                        .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(a, KeyEvent.KEYCODE_MEDIA_PLAY))
                )
            }
        } catch (_: Exception) {}
        repeat(10) {
            Thread.sleep(200)
            sessions(ctx).firstOrNull { it.packageName == pkg }?.let { return it }
        }
        return null
    }

    /**
     * Busca y reproduce una canción o playlist.
     * `kind` = "song" | "playlist". `pkg` vacío = la app predeterminada; si no hay, la primera conocida instalada.
     */
    fun playMusic(ctx: Context, query: String, kind: String, pkg: String): String {
        val q = query.trim()
        val target = pkg.ifBlank { getDefaultMusic(ctx) }
        backgroundPlay(ctx, q, kind, target)?.let { return it }
        // Segunda opción: si la principal no sonó en segundo plano, se prueba la de respaldo
        val backup = getBackupMusic(ctx)
        if (backup.isNotBlank() && backup != target && installed(ctx, backup)) {
            backgroundPlay(ctx, q, kind, backup)?.let { return it }
        }
        if (target.isNotBlank() && installed(ctx, target)) {
            val name = labelOf(ctx, target)
            val launch = ctx.packageManager.getLaunchIntentForPackage(target)
            if (q.isEmpty()) {
                if (launch != null && start(ctx, launch)) return ok(name)
            } else {
                val e = Uri.encode(q)
                val focus = if (kind == "playlist") "vnd.android.cursor.item/playlist" else "vnd.android.cursor.item/*"
                // 1) La orden estándar de Android "reproducir desde búsqueda"
                if (start(ctx, playFromSearch(q, target).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, focus))) return ok(name)
                // 2) Enlaces de búsqueda propios de cada app (esquema de la app y página web que la app sabe abrir)
                for (u in searchLinks(target, e)) {
                    if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)).setPackage(target))) return ok(name)
                }
                // 3) Enlaces de búsqueda sin fijar la app: si el esquema es de esa app, Android la elegirá
                for (u in searchLinks(target, e).filter { !it.startsWith("http") }) {
                    if (start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) return ok(name)
                }
                // 4) Buscador interno de la app (ACTION_SEARCH) y búsqueda web dentro de la app
                if (start(ctx, Intent(Intent.ACTION_SEARCH).setPackage(target).putExtra(SearchManager.QUERY, q))) return ok(name)
                if (start(ctx, Intent(Intent.ACTION_WEB_SEARCH).setPackage(target).putExtra(SearchManager.QUERY, q))) return ok(name)
                // 5) La app no acepta búsquedas desde fuera: se abre ESA app y se copia el nombre para pegarlo
                copyToClipboard(ctx, q)
                if (launch != null && start(ctx, launch)) {
                    return JSONObject().put("ok", true).put("app", name).put("searched", false).toString()
                }
            }
            return JSONObject().put("ok", false).put("err", "blocked").put("app", name).toString()
        }
        // Sin app elegida (o ya no está instalada): se busca con la primera que haya
        val fallbackQuery = if (kind == "playlist" && q.isNotEmpty()) "$q playlist" else q
        return playSong(ctx, fallbackQuery, "")
    }

    /** Enlaces de búsqueda conocidos de las apps de música más usadas; para el resto, enlaces genéricos. */
    private fun searchLinks(pkg: String, e: String): List<String> = when (pkg) {
        SPOTIFY -> listOf("spotify:search:$e", "https://open.spotify.com/search/$e")
        YT_MUSIC -> listOf("https://music.youtube.com/search?q=$e")
        YOUTUBE -> listOf("https://www.youtube.com/results?search_query=$e")
        "deezer.android.app" -> listOf("deezer://www.deezer.com/search/$e", "https://www.deezer.com/search/$e")
        "com.amazon.mp3" -> listOf("https://music.amazon.com/search/$e")
        "com.soundcloud.android" -> listOf("soundcloud://search?q=$e", "https://soundcloud.com/search?q=$e")
        "com.aspiro.tidal", "com.tidal.android" -> listOf("tidal://search?q=$e", "https://listen.tidal.com/search?q=$e")
        "com.apple.android.music" -> listOf("https://music.apple.com/search?term=$e")
        "com.audiomack" -> listOf("audiomack://search?q=$e", "https://audiomack.com/search?q=$e")
        "com.napster.service.android", "com.rhapsody.napster" -> listOf("https://play.napster.com/search?query=$e")
        "com.pandora.android" -> listOf("https://www.pandora.com/search/$e")
        "com.anghami" -> listOf("https://play.anghami.com/search/$e")
        "com.clearchannel.iheartradio.controller" -> listOf("https://www.iheart.com/search/?q=$e")
        else -> listOf("https://www.google.com/search?q=$e")
    }

    private fun copyToClipboard(ctx: Context, text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Jarvis", text))
        } catch (_: Exception) {}
    }

    /** Abre un chat de WhatsApp (o la app de mensajes) con el texto ya escrito; tú solo das a enviar. */
    fun composeMessage(ctx: Context, text: String, app: String): String {
        val pref = norm(app)
        val pkg = when {
            pref.contains("telegram") -> "org.telegram.messenger"
            pref.contains("messenger") -> "com.facebook.orca"
            pref.contains("mensaje") || pref.contains("sms") -> ""
            else -> "com.whatsapp"
        }
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        if (pkg.isNotEmpty() && installed(ctx, pkg)) {
            if (start(ctx, Intent(send).setPackage(pkg))) return ok(labelOf(ctx, pkg))
        }
        if (pkg.isEmpty()) {
            if (start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", text))) return ok("Mensajes")
        }
        val chooser = Intent.createChooser(send, "Enviar con…")
        return if (start(ctx, chooser)) ok("selector") else JSONObject().put("ok", false).toString()
    }

    /** Controla lo que esté sonando: play, pause, toggle, next, prev, vol_up, vol_down. */
    fun media(ctx: Context, action: String): String {
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        fun key(code: Int) {
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
        return try {
            when (action) {
                "play" -> key(KeyEvent.KEYCODE_MEDIA_PLAY)
                "pause" -> key(KeyEvent.KEYCODE_MEDIA_PAUSE)
                "toggle" -> key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                "next" -> key(KeyEvent.KEYCODE_MEDIA_NEXT)
                "prev" -> key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "vol_up" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "vol_down" -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                else -> return JSONObject().put("ok", false).toString()
            }
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).toString()
        }
    }
}
