package com.jarvis.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var summonPending = false

    /** ¿Nos llamaron como asistente (botón de encendido, atajo, botón de los ajustes rápidos, audífonos)? */
    private fun isSummon(i: android.content.Intent?): Boolean =
        i?.action == android.content.Intent.ACTION_ASSIST || i?.action == android.content.Intent.ACTION_VOICE_COMMAND

    private fun summonNow() {
        JarvisHub.js("window.__summon&&window.__summon()")
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (isSummon(intent)) summonNow()
    }

    private val permissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val ok = ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            JarvisHub.js("window.__micResult&&window.__micResult($ok)")
            askBatteryOnce()
        }

    private var pickKind = "tts"

    private val voiceFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            val kind = pickKind
            JarvisHub.js("window.__voiceImporting&&window.__voiceImporting('$kind')")
            Thread {
                val res = try {
                    if (kind == "rvc") {
                        val msg = RvcVoice.importFile(applicationContext, uri)
                        "true," + JSONObject.quote(msg)
                    } else {
                        val n = ExternalVoice.importZip(applicationContext, uri)
                        getSharedPreferences("jarvis", 0).edit().putString("tts_voice", ExternalVoice.PREFIX + n).apply()
                        JarvisHub.ifService { it.reloadVoice() }
                        "true," + JSONObject.quote("Voz “$n” importada y seleccionada. Pulsa ▶ Probar voz.")
                    }
                } catch (e: Throwable) {
                    "false," + JSONObject.quote(e.message ?: "No se pudo importar.")
                }
                JarvisHub.js("window.__voiceImported&&window.__voiceImported('$kind',$res)")
            }.start()
        }

    fun pickVoiceFile(kind: String) {
        pickKind = kind
        voiceFile.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "application/onnx", "*/*"))
    }

    fun askPermissions() {
        val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        permissions.launch(list.toTypedArray())
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // La página empieza siempre inactiva: si quedó un servicio viejo, se cierra.
        JarvisHub.stopService()

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        summonPending = isSummon(intent)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (summonPending) {
                    summonPending = false
                    // La página necesita un momento para estar lista antes de que le pidamos escuchar
                    view?.postDelayed({ summonNow() }, 1200)
                }
            }
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        JarvisHub.webView = web
        web.addJavascriptInterface(JarvisBridge(this), "AndroidJarvis")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Atrás no cierra a Jarvis: lo manda al fondo y sigue escuchando.
                moveTaskToBack(true)
            }
        })

        // Lo primero al abrir: pedir micrófono (audio y voz) y notificaciones, para que todo funcione desde la primera vez.
        askMissingPermissions()
    }

    private fun askMissingPermissions() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) {
            try { permissions.launch(missing.toTypedArray()) } catch (_: Exception) {}
        } else {
            askBatteryOnce()
        }
    }

    /** Una sola vez: pide que Jarvis no sea limitado por el ahorro de batería (en Xiaomi si no, el sistema lo corta en segundo plano). */
    private fun askBatteryOnce() {
        try {
            val prefs = getSharedPreferences("jarvis", 0)
            if (prefs.getBoolean("battery_asked", false)) return
            val pm = getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
            if (pm.isIgnoringBatteryOptimizations(packageName)) return
            prefs.edit().putBoolean("battery_asked", true).apply()
            startActivity(
                android.content.Intent(
                    android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    android.net.Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {}
    }

    override fun onStart() {
        super.onStart()
        JarvisHub.appVisible = true
        JarvisHub.ifService { it.refreshOverlay() }
    }

    override fun onStop() {
        super.onStop()
        JarvisHub.appVisible = false
        JarvisHub.ifService { it.refreshOverlay() }
        // Segundo intento: en algunos teléfonos (Xiaomi) la primera vez el sistema tarda en aceptar la ventana flotante
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!JarvisHub.appVisible) JarvisHub.ifService { it.refreshOverlay() }
        }, 900)
        // Evita que Chromium congele los temporizadores de la página en segundo plano.
        web.resumeTimers()
    }

    override fun onDestroy() {
        JarvisHub.appVisible = false
        if (isFinishing) JarvisHub.stopService()
        JarvisHub.webView = null
        web.destroy()
        super.onDestroy()
    }
}
