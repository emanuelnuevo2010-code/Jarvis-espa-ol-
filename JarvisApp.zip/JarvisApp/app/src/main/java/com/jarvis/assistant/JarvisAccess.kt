package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.media.AudioManager
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Servicio de accesibilidad con un único trabajo: cuando Jarvis abre una canción en tu app de música y la app no
 * empieza sola, toca por ti el botón de "play". No lee ni guarda nada de la pantalla.
 */
class JarvisAccess : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccess? = null

        /** Busca un botón de play en la pantalla de `pkg` y lo toca. true si ya suena (hay botón de pausa) o si tocó play. */
        fun pressPlay(pkg: String): Boolean = try { instance?.doPressPlay(pkg) ?: false } catch (e: Exception) { false }

        /** En una pantalla de resultados de búsqueda, toca el primer resultado (o el del artista si lo dijiste). */
        fun pressFirstResult(pkg: String, query: String): Boolean =
            try { instance?.doFirstResult(pkg, query) ?: false } catch (e: Exception) { false }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val playRe = Regex("(?i)\\b(play|reproducir|reproduce|reanudar|resume)\\b")
    private val pauseRe = Regex("(?i)\\b(pause|pausa|pausar)\\b")
    private val skipRe = Regex("(?i)(next|siguiente|prev|anterior|queue|cola|playlist|lista|shuffle|aleatorio|all|todo)")

    private fun doPressPlay(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        fun label(n: AccessibilityNodeInfo) = ((n.contentDescription ?: n.text)?.toString() ?: "")
        // Si hay un botón de pausa a la vista, la canción ya está sonando
        if (all.any { pauseRe.containsMatchIn(label(it)) && !skipRe.containsMatchIn(label(it)) }) return true
        val target = all.firstOrNull { playRe.containsMatchIn(label(it)) && !skipRe.containsMatchIn(label(it)) }
            ?: return tapBigPlay(all)
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        return (n ?: target).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Respaldo para botones sin nombre (como en SimpMusic): si se ve la pantalla del reproductor (tiene los tiempos
     * 00:01 / -03:55) y no suena nada, toca el botón grande de play, que está en el centro, a ~71 % de la altura.
     */
    private fun tapBigPlay(all: List<AccessibilityNodeInfo>): Boolean {
        val timeRe = Regex("^-?\\d{1,2}:\\d{2}$")
        val onPlayer = all.any { timeRe.matches(((it.contentDescription ?: it.text)?.toString() ?: "").trim()) }
        if (!onPlayer) return false
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.isMusicActive) return true          // ya suena: no tocar (pausaría)
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * 0.5f, dm.heightPixels * 0.71f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private val skipTabs = Regex("(?i)^(todo|todos|all|canciones|songs|tracks|pistas|artistas|artists|albumes|albums|playlists|listas|podcasts|videos|mas|more|buscar|search|inicio|home|biblioteca|library|filtros|recientes|recent|resultados|mejor resultado|top result)$")

    private fun rowText(n: AccessibilityNodeInfo?, depth: Int = 0): String {
        if (n == null || depth > 6) return ""
        val sb = StringBuilder((n.text ?: n.contentDescription)?.toString() ?: "")
        for (i in 0 until n.childCount) sb.append(' ').append(rowText(n.getChild(i), depth + 1))
        return sb.toString()
    }

    private fun doFirstResult(pkg: String, query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val nq = JarvisActions.norm(query)
        val artist = Regex("\\b(?:de|del|by|of)\\s+(.+)$").find(nq)?.groupValues?.get(1)
        val artistTokens = artist?.split(" ")?.filter { it.length >= 3 } ?: emptyList()
        val titleTokens = (if (artist != null) nq.removeSuffix(artist).trim().removeSuffix("de").removeSuffix("del").removeSuffix("by").removeSuffix("of") else nq)
            .split(" ").filter { it.length >= 3 }
        val h = resources.displayMetrics.heightPixels
        val seen = ArrayList<AccessibilityNodeInfo>()
        val rows = ArrayList<Pair<AccessibilityNodeInfo, String>>()
        for (n in all) {
            val t = ((n.text ?: n.contentDescription)?.toString() ?: "").trim()
            if (t.isEmpty() || n.isEditable || skipTabs.matches(JarvisActions.norm(t)) || JarvisActions.norm(t) == nq) continue
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top < h * 0.18 || r.bottom > h * 0.92) continue
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c == null || seen.contains(c)) continue
            seen.add(c)
            rows.add(c to JarvisActions.norm(rowText(c)))
        }
        if (rows.isEmpty()) return false
        val pick =
            (if (artistTokens.isNotEmpty()) rows.firstOrNull { r -> artistTokens.all { r.second.contains(it) } && titleTokens.any { r.second.contains(it) } } else null)
                ?: rows.firstOrNull { r -> titleTokens.isNotEmpty() && titleTokens.count { r.second.contains(it) } >= minOf(2, titleTokens.size) }
                ?: rows.first()
        return pick.first.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 25 || out.size > 400) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }
}
