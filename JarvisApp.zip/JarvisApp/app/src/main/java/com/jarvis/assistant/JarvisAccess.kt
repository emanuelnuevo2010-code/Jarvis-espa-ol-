package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.os.SystemClock
import android.media.AudioManager
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Servicio de accesibilidad con un único trabajo: cuando Jarvis abre una canción en tu app de música y la app no
 * empieza sola, toca por ti el botón de "play". No lee ni guarda nada de la pantalla.
 */
class JarvisAccess : AccessibilityService() {

    companion object {
        @Volatile var instance: JarvisAccess? = null

        /** Busca un botón de play en la pantalla de `pkg` y lo toca. true si ya suena (hay botón de pausa) o si tocó play. */
        fun pressPlay(pkg: String): Boolean = try { instance?.doPressPlay(pkg) ?: false } catch (e: Exception) { false }

        /** ¿Está activado este servicio de accesibilidad? */
        fun isOn(): Boolean = instance != null

        /** En el chat de WhatsApp `pkg`, si el cuadro de texto trae ese mensaje, toca el botón de enviar. */
        fun pressSend(pkg: String, text: String): Boolean =
            try { instance?.doPressSend(pkg, text) ?: false } catch (e: Exception) { false }

        /**
         * En "compartir con…" de WhatsApp: busca `name`, toca ese contacto y envía `text`. Bloquea hasta ~25 s (llamar desde un hilo).
         * true si se mandó. Si el nombre no aparece o hay varios distintos, no manda nada.
         */
        fun shareToContact(pkg: String, name: String, text: String): Boolean {
            val me = instance ?: return false
            val st = ShareState()
            val end = SystemClock.uptimeMillis() + 25000
            while (SystemClock.uptimeMillis() < end) {
                try { Thread.sleep(600) } catch (_: InterruptedException) {}
                val r = try { me.shareStep(pkg, name, text, st) } catch (e: Exception) { 0 }
                if (r != 0) return r > 0
            }
            return false
        }

        /** ¿Se ve una pantalla de resultados de búsqueda de esa app (caja de búsqueda con lo pedido, o pestañas Canciones/Artistas)? */
        fun onResults(pkg: String, query: String): Boolean =
            try { instance?.doOnResults(pkg, query) ?: false } catch (e: Exception) { false }

        /** En una pantalla de resultados de búsqueda, toca el primer resultado (o el del artista si lo dijiste). */
        fun pressFirstResult(pkg: String, query: String, skip: Int = 0): Boolean =
            try { instance?.doFirstResult(pkg, query, skip) ?: false } catch (e: Exception) { false }
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private val playRe = Regex("(?i)\\b(play|reproducir|reproduce|reanudar|resume)\\b")
    private val pauseRe = Regex("(?i)\\b(pause|pausa|pausar)\\b")
    private val skipRe = Regex("(?i)(next|siguiente|prev|anterior|queue|cola|playlist|lista|shuffle|aleatorio|all|todo)")

    private fun doPressPlay(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        fun label(n: AccessibilityNodeInfo) = ((n.contentDescription ?: n.text)?.toString() ?: "")
        // Si hay un botón de pausa a la vista, la canción ya está sonando
        if (all.any { pauseRe.containsMatchIn(label(it)) && !skipRe.containsMatchIn(label(it)) }) return true
        val target = all.firstOrNull { playRe.containsMatchIn(label(it)) && !skipRe.containsMatchIn(label(it)) }
            ?: return tapBigPlay(all)
        var n: AccessibilityNodeInfo? = target
        while (n != null && !n.isClickable) n = n.parent
        return (n ?: target).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /**
     * Respaldo para botones sin nombre (como en SimpMusic): si se ve la pantalla del reproductor (tiene los tiempos
     * 00:01 / -03:55) y no suena nada, toca el botón grande de play, que está en el centro, a ~71 % de la altura.
     */
    private fun tapBigPlay(all: List<AccessibilityNodeInfo>): Boolean {
        val timeRe = Regex("^-?\\d{1,2}:\\d{2}$")
        val onPlayer = all.any { timeRe.matches(((it.contentDescription ?: it.text)?.toString() ?: "").trim()) }
        if (!onPlayer) return false
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.isMusicActive) return true          // ya suena: no tocar (pausaría)
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * 0.5f, dm.heightPixels * 0.71f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private val skipTabs = Regex("(?i)^(todo|todos|all|canciones|songs|tracks|pistas|artistas|artists|albumes|albums|playlists|listas|podcasts|videos|mas|more|buscar|search|inicio|home|biblioteca|library|filtros|recientes|recent|resultados|mejor resultado|top result)$")

    private fun rowText(n: AccessibilityNodeInfo?, depth: Int = 0): String {
        if (n == null || depth > 6) return ""
        val sb = StringBuilder((n.text ?: n.contentDescription)?.toString() ?: "")
        for (i in 0 until n.childCount) sb.append(' ').append(rowText(n.getChild(i), depth + 1))
        return sb.toString()
    }

    private val tabRe = Regex("^(canciones|songs|tracks|artistas|artists|albumes|albums|playlists|listas|videos)$")

    private fun doOnResults(pkg: String, query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val tokens = JarvisActions.queryTokens(query)
        var tabs = 0
        for (n in all) {
            val t = JarvisActions.norm(((n.text ?: n.contentDescription)?.toString() ?: ""))
            if (t.isEmpty()) continue
            if (n.isEditable && tokens.any { t.contains(it) }) return true
            if (tabRe.matches(t)) tabs++
        }
        return tabs >= 2
    }

    private fun doFirstResult(pkg: String, query: String, skip: Int = 0): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != pkg) return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        val nq = JarvisActions.norm(query)
        val artist = Regex("\\b(?:de|del|by|of)\\s+(.+)$").find(nq)?.groupValues?.get(1)
        val artistTokens = artist?.split(" ")?.filter { it.length >= 3 } ?: emptyList()
        val titleTokens = (if (artist != null) nq.removeSuffix(artist).trim().removeSuffix("de").removeSuffix("del").removeSuffix("by").removeSuffix("of") else nq)
            .split(" ").filter { it.length >= 3 }
        val h = resources.displayMetrics.heightPixels
        val seen = ArrayList<AccessibilityNodeInfo>()
        val rows = ArrayList<Pair<AccessibilityNodeInfo, String>>()
        for (n in all) {
            val t = ((n.text ?: n.contentDescription)?.toString() ?: "").trim()
            if (t.isEmpty() || n.isEditable || skipTabs.matches(JarvisActions.norm(t)) || JarvisActions.norm(t) == nq) continue
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.top < h * 0.18 || r.bottom > h * 0.92) continue
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c == null || seen.contains(c)) continue
            seen.add(c)
            rows.add(c to JarvisActions.norm(rowText(c)))
        }
        if (rows.isEmpty()) return false
        val allTokens = JarvisActions.queryTokens(query)
        fun hits(t: String, tokens: List<String>) = tokens.count { t.contains(it) }
        if (skip > 0) {
            // «Otra opción»: el resultado número `skip` (contando desde el primero) entre los que se parecen a lo pedido, de arriba abajo
            val ranked = rows.filter { allTokens.isNotEmpty() && hits(it.second, allTokens) > 0 }.ifEmpty { rows }
            val p = ranked.getOrNull(skip) ?: ranked.last()
            return p.first.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        val pick =
            (if (artistTokens.isNotEmpty()) rows.firstOrNull { r -> artistTokens.all { r.second.contains(it) } && titleTokens.any { r.second.contains(it) } } else null)
                ?: rows.filter { r -> titleTokens.isNotEmpty() && hits(r.second, titleTokens) >= minOf(2, titleTokens.size) }
                    .maxByOrNull { hits(it.second, allTokens) }
                ?: rows.filter { r -> allTokens.isNotEmpty() && hits(r.second, allTokens) > 0 }.maxByOrNull { hits(it.second, allTokens) }
                ?: rows.first()
        return pick.first.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private val sendRe = Regex("(?i)^(enviar|send)( mensaje| message)?$")
    private val searchRe = Regex("(?i)^(buscar|search|buscar.*|search.*)$")

    class ShareState {
        var typedAt = 0L      // cuándo se escribió el nombre en el buscador
        var picked = false    // ya se tocó el contacto
        var clickedAt = 0L    // cuándo se tocó "Enviar" en la confirmación
    }

    /** Un paso: 0 = seguir esperando, 1 = enviado, -1 = abortar (sin mandar). */
    private fun shareStep(pkg: String, name: String, text: String, st: ShareState): Int {
        val root = rootFor(pkg) ?: return 0
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        fun label(n: AccessibilityNodeInfo) = ((n.text ?: n.contentDescription)?.toString() ?: "").trim()
        fun clickUp(n: AccessibilityNodeInfo): Boolean {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            return (c ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // 1) Ya hay un cuadro con el mensaje (chat o vista previa): enviar
        val want = JarvisActions.norm(text).take(12)
        if (all.any { it.isEditable && JarvisActions.norm((it.text ?: "").toString()).contains(want) }) {
            if (doPressSend(pkg, text)) { try { Thread.sleep(700) } catch (_: InterruptedException) {}; return 1 }
            return 0
        }
        // 2) Ya se eligió el contacto: confirmar con "Enviar" y dar un momento por si aparece otra pantalla
        if (st.picked) {
            if (st.clickedAt != 0L) return if (SystemClock.uptimeMillis() - st.clickedAt > 3000) 1 else 0
            val btn = all.firstOrNull { sendRe.matches(label(it)) || (it.viewIdResourceName ?: "").endsWith(":id/send") }
            if (btn != null && clickUp(btn)) st.clickedAt = SystemClock.uptimeMillis()
            return 0
        }
        // 3) Pantalla de elegir contacto: buscar el nombre
        val nq = JarvisActions.norm(name)
        val tokens = nq.split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) return -1
        val edit = all.firstOrNull { it.isEditable }
        if (edit != null) {
            if (JarvisActions.norm((edit.text ?: "").toString()) != nq) {
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, name) }
                edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (st.typedAt == 0L) st.typedAt = SystemClock.uptimeMillis()
                return 0
            }
            val h = resources.displayMetrics.heightPixels
            val rows = LinkedHashMap<String, AccessibilityNodeInfo>()
            for (n in all) {
                if (n.isEditable) continue
                val t = JarvisActions.norm(label(n))
                if (t.isEmpty() || !tokens.all { t.contains(it) }) continue
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.top < h * 0.12) continue
                rows.putIfAbsent(t, n)
            }
            if (rows.size > 1) return -1                      // varios contactos distintos: no adivinar
            if (rows.size == 1) { if (clickUp(rows.values.first())) st.picked = true; return 0 }
            return if (SystemClock.uptimeMillis() - st.typedAt > 7000) -1 else 0
        }
        // 4) Aún no hay buscador: tocar la lupa
        all.firstOrNull { searchRe.matches(label(it)) && !it.isEditable }?.let { clickUp(it) }
        return 0
    }

    /** Ventana de la app `pkg`: la activa o, si algo (la isla flotante, un teclado) la tapa, la que se vea con ese paquete. */
    private fun rootFor(pkg: String): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { if (it.packageName?.toString() == pkg) return it }
        return try { windows.mapNotNull { it.root }.firstOrNull { it.packageName?.toString() == pkg } } catch (_: Exception) { null }
    }

    /** Clic normal; si la app lo ignora, un toque real en el centro del botón. */
    private fun clickOrTap(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if ((c ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        return try {
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.isEmpty) return false
            val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
            dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 70)).build(), null, null)
        } catch (_: Exception) { false }
    }

    private fun doPressSend(pkg: String, text: String): Boolean {
        val root = rootFor(pkg) ?: return false
        val all = ArrayList<AccessibilityNodeInfo>()
        collect(root, all, 0)
        // Solo se envía si el cuadro de texto ya trae el mensaje (así sabemos que es el chat correcto)
        val want = JarvisActions.norm(text).take(12)
        val hasText = all.any { it.isEditable && JarvisActions.norm((it.text ?: "").toString()).contains(want) }
        if (!hasText) return false
        val btn = all.firstOrNull { (it.viewIdResourceName ?: "") == "$pkg:id/send" }
            ?: all.firstOrNull { sendRe.matches(((it.contentDescription ?: it.text)?.toString() ?: "").trim()) }
            ?: all.firstOrNull { (it.viewIdResourceName ?: "").lowercase().let { id -> id.endsWith("/send") || id.endsWith("/send_btn") || id.endsWith("/conversation_send") } }
            ?: return false
        return clickOrTap(btn)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 25 || out.size > 400) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }
}
