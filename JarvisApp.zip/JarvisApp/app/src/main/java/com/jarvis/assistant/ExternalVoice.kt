package com.jarvis.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.provider.OpenableColumns
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Voces externas: modelos de voz (Piper / VITS) importados desde un archivo .zip.
 *
 * Cada voz vive en  filesDir/voices/<nombre>/  y debe contener como mínimo:
 *   - un archivo  *.onnx   (el modelo)
 *   - tokens.txt
 *   - (casi siempre) la carpeta espeak-ng-data/   y a veces lexicon.txt
 * Se reproduce con sherpa-onnx; la voz se elige en Ajustes con el prefijo "ext:".
 */
object ExternalVoice {
    const val PREFIX = "ext:"

    private val exec = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private var tts: OfflineTts? = null
    private var loaded: String? = null
    @Volatile private var gen = 0
    @Volatile private var track: AudioTrack? = null

    private fun root(ctx: Context) = File(ctx.filesDir, "voices").apply { mkdirs() }

    /** Nombres de las voces importadas. */
    fun list(ctx: Context): List<String> =
        root(ctx).listFiles()?.filter { it.isDirectory && findModel(it) != null }?.map { it.name }?.sorted() ?: emptyList()

    private class Model(val onnx: File, val tokens: File, val data: File?, val lexicon: File?)

    private fun findModel(dir: File): Model? {
        val tokens = dir.walkTopDown().firstOrNull { it.isFile && it.name == "tokens.txt" } ?: return null
        val base = tokens.parentFile ?: return null
        val onnx = base.listFiles()?.filter { it.isFile && it.name.endsWith(".onnx") }
            ?.sortedBy { it.name }?.firstOrNull() ?: return null
        val data = File(base, "espeak-ng-data").takeIf { it.isDirectory }
        val lex = File(base, "lexicon.txt").takeIf { it.isFile }
        return Model(onnx, tokens, data, lex)
    }

    /* ---------- importar / borrar ---------- */

    /** Descomprime el .zip elegido en voices/<nombre>/. Lanza una excepción con un mensaje claro si no sirve. */
    fun importZip(ctx: Context, uri: Uri): String {
        var display = "voz"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) display = it.getString(0) ?: display
        }
        val name = display.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9._-]"), "_").take(60).ifBlank { "voz" }
        val dest = File(root(ctx), name)
        if (dest.exists()) dest.deleteRecursively()
        dest.mkdirs()
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: error("No pude abrir el archivo.")
            ZipInputStream(input.buffered()).use { zin ->
                val destPath = dest.canonicalPath + File.separator
                while (true) {
                    val e = zin.nextEntry ?: break
                    val out = File(dest, e.name)
                    if (!out.canonicalPath.startsWith(destPath)) continue   // protección contra rutas maliciosas
                    if (e.isDirectory) { out.mkdirs(); continue }
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
            }
            if (findModel(dest) == null) error("El .zip no trae un modelo de voz: busco un archivo .onnx y un tokens.txt.")
        } catch (e: Exception) {
            dest.deleteRecursively()
            throw e
        }
        synchronized(lock) { if (loaded == name) { try { tts?.release() } catch (_: Throwable) {}; tts = null; loaded = null } }
        return name
    }

    fun delete(ctx: Context, name: String) {
        synchronized(lock) { if (loaded == name) { try { tts?.release() } catch (_: Throwable) {}; tts = null; loaded = null } }
        File(root(ctx), name).deleteRecursively()
    }

    fun exists(ctx: Context, name: String) = File(root(ctx), name).let { it.isDirectory && findModel(it) != null }

    /* ---------- cargar y hablar ---------- */

    private fun ensure(ctx: Context, name: String): OfflineTts {
        synchronized(lock) {
            if (loaded == name && tts != null) return tts!!
            try { tts?.release() } catch (_: Throwable) {}
            tts = null; loaded = null
            val m = findModel(File(root(ctx), name)) ?: error("Voz no encontrada")
            val vits = OfflineTtsVitsModelConfig(
                model = m.onnx.absolutePath,
                tokens = m.tokens.absolutePath,
                dataDir = m.data?.absolutePath ?: "",
                lexicon = m.lexicon?.absolutePath ?: ""
            )
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(vits = vits, numThreads = 2, debug = false, provider = "cpu")
            )
            val t = OfflineTts(config = cfg)
            tts = t; loaded = name
            return t
        }
    }

    /** Carga el modelo en segundo plano para que la primera frase no tarde. */
    fun preload(ctx: Context, name: String) {
        val app = ctx.applicationContext
        exec.execute { try { ensure(app, name) } catch (_: Throwable) {} }
    }

    /**
     * Dice el texto. Al terminar llama a onDone; si el modelo no carga o falla, llama a onFail
     * (para que quien llama use la voz del sistema). Si la frase se corta con stop() u otra frase, no llama a nada.
     */
    fun speak(ctx: Context, name: String, text: String, speed: Float, onDone: () -> Unit, onFail: () -> Unit) {
        val app = ctx.applicationContext
        val my = ++gen
        stopTrack()
        exec.execute {
            if (my != gen) return@execute
            var played = 0L
            var sr = 22050
            var at: AudioTrack? = null
            try {
                val t = ensure(app, name)
                sr = t.sampleRate()
                val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
                at = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder().setSampleRate(sr)
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, sr * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if (my != gen) { at.release(); return@execute }
                track = at
                at.play()
                val a = at
                t.generateWithCallback(text = text, sid = 0, speed = speed.coerceIn(0.5f, 2f)) { samples ->
                    if (my != gen) return@generateWithCallback 0
                    a.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
                    played += samples.size
                    1
                }
                // esperar a que suene lo que quedó en el búfer
                var waited = 0
                while (my == gen && a.playbackHeadPosition < played && waited < 600) {
                    Thread.sleep(20); waited++
                }
                if (my == gen) {
                    try { a.stop() } catch (_: Exception) {}
                    onDone()
                }
            } catch (e: Throwable) {
                if (my == gen) onFail()
            } finally {
                try { at?.release() } catch (_: Exception) {}
                if (track === at) track = null
            }
        }
    }

    /** Genera el audio completo de una frase (para que RVC lo convierta). Bloquea. */
    fun render(ctx: Context, name: String, text: String, speed: Float): Pair<FloatArray, Int>? = try {
        val a = ensure(ctx.applicationContext, name).generate(text = text, sid = 0, speed = speed.coerceIn(0.5f, 2f))
        a.samples to a.sampleRate
    } catch (e: Throwable) { null }

    private fun stopTrack() {
        val t = track ?: return
        try { t.pause(); t.flush() } catch (_: Exception) {}
    }

    /** Corta lo que esté sonando. */
    fun stop() { gen++; stopTrack() }

    /** Libera el modelo de la memoria. */
    fun release() {
        gen++; stopTrack()
        exec.execute { synchronized(lock) { try { tts?.release() } catch (_: Throwable) {}; tts = null; loaded = null } }
    }
}
