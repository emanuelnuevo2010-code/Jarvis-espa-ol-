package com.jarvis.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Oye "Jarvis" sin pausar la música: usa un detector sin internet (Vosk) que lee el micrófono directamente.
 * A diferencia del reconocimiento de voz de Android, esto NO pide el foco de audio, así la canción sigue sonando.
 * Solo busca la palabra "jarvis"; no guarda ni envía lo que oye.
 */
object WakeWord {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"

    @Volatile private var thread: Thread? = null
    @Volatile private var stopFlag = false
    @Volatile private var downloading = false
    private var model: Model? = null

    /** Último fallo del detector (para mostrarlo en Ajustes). */
    @Volatile var lastError: String = ""
    fun running(): Boolean = thread != null

    // Palabras que el detector acepta como «Jarvis». Se listan varias porque el modelo es en inglés y quien habla español dice «Járvis»
    // casi como «harvest/Jervis»; las que no existan en el modelo las ignora, así que basta con que alguna exista.
    private val GRAMMAR = "[\"jarvis\", \"jervis\", \"gervais\", \"harvest\", \"harvey\", \"harvis\", \"yarvis\", \"[unk]\"]"
    private val HIT = Regex("(?i)\\b(jarvis|jervis|gervais|harvest|harvey|harvis|yarvis|hervis)\\b")

    private fun dir(ctx: Context) = File(ctx.filesDir, "vosk-wake")

    /** ¿Ya está descargado el modelo del detector (unos 40 MB)? */
    fun ready(ctx: Context): Boolean = File(dir(ctx), "am/final.mdl").exists()

    /** Descarga y descomprime el modelo una sola vez. `onDone(true)` si quedó listo. */
    fun download(ctx: Context, onProgress: (Int) -> Unit = {}, onDone: (Boolean) -> Unit) {
        if (ready(ctx)) { onDone(true); return }
        if (downloading) return
        downloading = true
        val app = ctx.applicationContext
        Thread {
            var ok = false
            try {
                val tmp = File(app.filesDir, "vosk-wake.tmp")
                tmp.deleteRecursively()
                val c = URL(MODEL_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000
                val total = c.contentLengthLong
                var got = 0L; var last = -1
                val counted = object : java.io.FilterInputStream(c.inputStream) {
                    override fun read(b: ByteArray, off: Int, len: Int): Int {
                        val n = super.read(b, off, len)
                        if (n > 0 && total > 0) { got += n; val p = (got * 100 / total).toInt() / 10 * 10; if (p != last) { last = p; onProgress(p) } }
                        return n
                    }
                }
                ZipInputStream(counted.buffered()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val name = e.name.substringAfter('/')          // quita la carpeta raíz del zip
                        if (name.isNotEmpty()) {
                            val f = File(tmp, name)
                            if (f.canonicalPath.startsWith(tmp.canonicalPath)) {
                                if (e.isDirectory) f.mkdirs()
                                else { f.parentFile?.mkdirs(); f.outputStream().use { o -> z.copyTo(o) } }
                            }
                        }
                        e = z.nextEntry
                    }
                }
                val d = dir(app)
                d.deleteRecursively()
                ok = tmp.renameTo(d)
            } catch (e: Throwable) { lastError = "descarga: " + (e.message ?: e.javaClass.simpleName) }
            downloading = false
            onDone(ok)
        }.start()
    }

    /** Empieza a escuchar solo la palabra "jarvis". Si ya está escuchando, no hace nada. `onHit` se llama una vez al oírla. */
    @Synchronized fun start(ctx: Context, onHit: () -> Unit) {
        if (thread != null || !ready(ctx)) return
        stopFlag = false
        val app = ctx.applicationContext
        val t = Thread {
            var rec: AudioRecord? = null
            var r: Recognizer? = null
            var hit = false
            try {
                val m = model ?: Model(dir(app).absolutePath).also { model = it }
                r = Recognizer(m, 16000f, GRAMMAR)
                val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                fun openRec(src: Int) = AudioRecord(src, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8192) * 2)
                rec = openRec(MediaRecorder.AudioSource.MIC)
                if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); rec = openRec(MediaRecorder.AudioSource.VOICE_RECOGNITION) }
                if (rec.state != AudioRecord.STATE_INITIALIZED) lastError = "no pude abrir el micrófono"
                else {
                    lastError = ""
                    rec.startRecording()
                    val buf = ByteArray(4096)
                    while (!stopFlag) {
                        val n = rec.read(buf, 0, buf.size)
                        if (n <= 0) continue
                        val txt = if (r.acceptWaveForm(buf, n)) r.result else r.partialResult
                        if (HIT.containsMatchIn(txt)) { hit = true; break }
                    }
                }
            } catch (e: Throwable) {
                lastError = e.message ?: e.javaClass.simpleName
            } finally {
                try { rec?.stop() } catch (_: Throwable) {}
                try { rec?.release() } catch (_: Throwable) {}
                try { r?.close() } catch (_: Throwable) {}
                thread = null
            }
            if (hit && !stopFlag) onHit()
        }
        t.isDaemon = true
        thread = t
        t.start()
    }

    /** Suelta el micrófono (hay que llamarlo antes de que escuche el reconocimiento de voz normal). */
    fun stop() {
        val t = thread ?: return
        stopFlag = true
        try { if (Thread.currentThread() !== t) t.join(1500) } catch (_: Exception) {}
    }
}
