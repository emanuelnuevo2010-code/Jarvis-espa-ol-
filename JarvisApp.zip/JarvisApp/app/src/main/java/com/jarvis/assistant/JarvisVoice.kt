package com.jarvis.assistant

import android.content.Context
import android.speech.tts.TextToSpeech

/** Voz elegida para Jarvis (voz, velocidad y tono), guardada en las preferencias. */
object JarvisVoice {

    /** Si la voz elegida es un modelo importado desde archivo, devuelve su nombre; si no, null. */
    fun external(ctx: Context): String? {
        val name = ctx.getSharedPreferences("jarvis", 0).getString("tts_voice", "") ?: ""
        if (!name.startsWith(ExternalVoice.PREFIX)) return null
        val n = name.removePrefix(ExternalVoice.PREFIX)
        return if (ExternalVoice.exists(ctx, n)) n else null
    }

    fun rate(ctx: Context): Float = ctx.getSharedPreferences("jarvis", 0).getFloat("tts_rate", 1.05f)

    fun apply(ctx: Context, t: TextToSpeech) {
        val p = ctx.getSharedPreferences("jarvis", 0)
        val name = p.getString("tts_voice", "") ?: ""
        if (name.isNotBlank() && !name.startsWith(ExternalVoice.PREFIX)) {
            try { t.voices?.firstOrNull { it.name == name }?.let { t.voice = it } } catch (_: Exception) {}
        }
        t.setSpeechRate(p.getFloat("tts_rate", 1.05f))
        t.setPitch(p.getFloat("tts_pitch", 1.0f))
    }
}
