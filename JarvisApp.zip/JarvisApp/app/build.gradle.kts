plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jarvis.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jarvis.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 42
        versionName = "3.21"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Para uso personal: firma con la llave de depuración para que se pueda instalar
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        // sherpa-onnx y onnxruntime-android traen cada uno su libonnxruntime.so
        jniLibs { pickFirsts += setOf("**/libonnxruntime.so") }
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.webkit:webkit:1.11.0")
    // Motor de voz para modelos externos (Piper/VITS). El .aar se descarga a app/libs (ver README).
    // ONNX Runtime para los modelos RVC (conversión de voz)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.22.0")
    // Detector de la palabra "Jarvis" sin internet y sin pausar la música (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.aar"))))
}
